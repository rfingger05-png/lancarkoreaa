
import React, { useState, useMemo, FC } from 'react';
import { Vocab } from '../types';

interface ChapterDetailProps {
  chapterId: number;
  vocabs: Vocab[];
  onBack: () => void;
}

type DetailMode = 'biasa' | 'gambar';

const ChapterDetail: FC<ChapterDetailProps> = ({ chapterId, vocabs, onBack }) => {
  const [detailMode, setDetailMode] = useState<DetailMode>('biasa');
  const [revealedIds, setRevealedIds] = useState<Set<string>>(new Set());

  const chVocabs = useMemo(() => vocabs.filter(v => v.chapterId === chapterId), [vocabs, chapterId]);
  
  const filteredItems = useMemo(() => {
    if (detailMode === 'gambar') {
      return chVocabs.filter(v => !!v.imageUrl);
    }
    return chVocabs.filter(v => !v.imageUrl);
  }, [chVocabs, detailMode]);

  const countBiasa = chVocabs.filter(v => !v.imageUrl).length;
  const countGambar = chVocabs.filter(v => !!v.imageUrl).length;

  const toggleReveal = (id: string) => {
    const newRevealed = new Set(revealedIds);
    if (newRevealed.has(id)) {
      newRevealed.delete(id);
    } else {
      newRevealed.add(id);
    }
    setRevealedIds(newRevealed);
  };

  return (
    <div className="min-h-screen bg-zinc-950 space-y-6 pb-20">
      {/* Header Area */}
      <div className="flex flex-col gap-6 mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button 
              onClick={onBack}
              className="bg-slate-900 border border-slate-800 p-2.5 rounded-xl hover:bg-slate-800 transition-all shadow-lg active:scale-95 group"
            >
              <svg className="w-6 h-6 text-slate-400 group-hover:text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h2 className="text-3xl font-black text-white">Bab {chapterId}</h2>
              <p className="text-slate-500 text-xs font-medium uppercase tracking-widest mt-0.5">Materi Pembelajaran</p>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-2xl w-full md:w-auto">
          <button 
            onClick={() => { setDetailMode('biasa'); setRevealedIds(new Set()); }}
            className={`flex-1 md:flex-none flex items-center justify-center px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-tighter transition-all ${
              detailMode === 'biasa' 
                ? 'bg-blue-600 text-white shadow-lg' 
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Kosakata Biasa
            <span className={`ml-2 px-1.5 py-0.5 rounded-md text-[9px] ${detailMode === 'biasa' ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-500'}`}>
              {countBiasa}
            </span>
          </button>
          <button 
            onClick={() => { setDetailMode('gambar'); setRevealedIds(new Set()); }}
            className={`flex-1 md:flex-none flex items-center justify-center px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-tighter transition-all ${
              detailMode === 'gambar' 
                ? 'bg-emerald-600 text-white shadow-lg' 
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Kosakata Gambar
            <span className={`ml-2 px-1.5 py-0.5 rounded-md text-[9px] ${detailMode === 'gambar' ? 'bg-emerald-500 text-white' : 'bg-slate-800 text-slate-500'}`}>
              {countGambar}
            </span>
          </button>
        </div>
      </div>

      {/* Grid Content */}
      {filteredItems.length === 0 ? (
        <div className="py-24 text-center bg-slate-900/40 border-2 border-dashed border-slate-800 rounded-[2.5rem] flex flex-col items-center">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 ${detailMode === 'gambar' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-blue-500/10 text-blue-500'}`}>
             {detailMode === 'gambar' ? (
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
             ) : (
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
             )}
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Tidak ada data</h3>
          <p className="text-slate-500 max-w-xs mx-auto text-sm">Belum ada {detailMode === 'gambar' ? 'kosakata bergambar' : 'kosakata biasa'} yang ditambahkan di Bab {chapterId}.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((v) => {
            const isRevealed = revealedIds.has(v.id);
            return (
              <div 
                key={v.id} 
                onClick={() => toggleReveal(v.id)}
                className={`relative min-h-[220px] rounded-3xl cursor-pointer transition-all duration-300 border-2 overflow-hidden flex flex-col group shadow-lg active:scale-[0.98] ${
                   isRevealed 
                    ? (detailMode === 'gambar' ? 'bg-emerald-900/40 border-emerald-500' : 'bg-blue-900/40 border-blue-500')
                    : 'bg-slate-900 border-slate-800 hover:border-slate-600'
                }`}
              >
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                  {!isRevealed ? (
                    /* Tampilan Awal (Prompt) */
                    <div className="flex flex-col items-center">
                      {detailMode === 'gambar' ? (
                        <div className="relative w-full h-32 mb-4">
                          <img src={v.imageUrl} alt="Visual" className="w-full h-full object-contain drop-shadow-lg" />
                        </div>
                      ) : (
                        <h4 className="text-4xl font-black text-white tracking-tight leading-tight mb-2">{v.word}</h4>
                      )}
                      <p className={`text-[10px] font-black uppercase tracking-[0.2em] mt-2 ${detailMode === 'gambar' ? 'text-emerald-500' : 'text-blue-500'}`}>
                        Klik untuk melihat {detailMode === 'gambar' ? 'kata' : 'arti'}
                      </p>
                    </div>
                  ) : (
                    /* Tampilan Setelah Klik (Answer) */
                    <div className="flex flex-col items-center">
                      <div className={`mb-2 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${detailMode === 'gambar' ? 'bg-emerald-500 text-white' : 'bg-blue-500 text-white'}`}>
                        {detailMode === 'gambar' ? 'Kata Korea' : 'Arti Indonesia'}
                      </div>
                      <h4 className="text-4xl font-black text-white tracking-tight leading-tight">
                        {detailMode === 'gambar' ? v.word : v.meaning}
                      </h4>
                      <div className={`h-1 w-8 mt-4 rounded-full ${detailMode === 'gambar' ? 'bg-emerald-500' : 'bg-blue-500'}`}></div>
                      
                      {/* Sub-info */}
                      <div className="mt-4 flex flex-col items-center space-y-1 opacity-60">
                        <p className="text-xs font-bold text-slate-300 italic">
                          {detailMode === 'gambar' ? v.meaning : v.word}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Indikator Status di bagian bawah */}
                <div className={`h-1.5 w-full ${isRevealed ? (detailMode === 'gambar' ? 'bg-emerald-500' : 'bg-blue-500') : 'bg-slate-800'}`}></div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ChapterDetail;
