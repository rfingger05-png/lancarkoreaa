
import { useState, useEffect, FC, FormEvent } from 'react';
import { User } from '../types';
import { Lock, User as UserIcon, LogIn, AlertCircle, CheckCircle2 } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: FC<LoginProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [invitationCode, setInvitationCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const [successMessage, setSuccessMessage] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    setLoading(true);

    try {
      const endpoint = isLogin ? '/api/login' : '/api/register';
      const payload = isLogin ? { email, password } : { email, password, invitationCode };
      
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      // Check if response is JSON
      const contentType = res.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await res.text();
        console.error('Non-JSON response received:', text);
        
        if (text.includes('Konfigurasi Supabase')) {
          throw new Error('Konfigurasi Supabase belum lengkap di Netlify. Pastikan Environment Variables sudah diatur di Dashboard Netlify.');
        }

        if (text.includes('<title>Lancar Korea</title>') || text.includes('id="root"')) {
          throw new Error('Netlify salah mengarahkan rute (SPA Fallback). Server malah mengirimkan halaman web bukannya data.');
        }
        
        // Show a snippet of the non-JSON response to help debug
        const snippet = text.substring(0, 100).replace(/<[^>]*>/g, '').trim();
        throw new Error(`Server mengirimkan format salah (${res.status}). Pesan: ${snippet || 'Tidak ada pesan'}`);
      }

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || (isLogin ? 'Login gagal' : 'Registrasi gagal'));
      }

      if (data.requiresConfirmation) {
        setSuccessMessage(data.message);
        setIsLogin(true); // Switch to login after registration
        return;
      }

      onLogin(data);
    } catch (err: any) {
      setError(err.message || 'Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic">
            Lancar <span className="text-blue-500">Korea</span>
          </h1>
          <p className="text-zinc-500 font-bold text-xs uppercase tracking-[0.3em] mt-2">
            {isLogin ? 'Learning Management System' : 'Create New Account'}
          </p>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-[2rem] p-8 shadow-2xl relative overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none"></div>
          
          {/* Status Indicators */}
          <div className="absolute top-6 right-8 flex gap-2 z-20">
            <div className="flex items-center gap-1.5 px-2 py-1 bg-zinc-950/50 border border-zinc-800 rounded-full">
              <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.5)]"></div>
              <span className="text-[8px] font-black text-zinc-500 uppercase tracking-tighter">System</span>
            </div>
            <div className="flex items-center gap-1.5 px-2 py-1 bg-zinc-950/50 border border-zinc-800 rounded-full">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
              <span className="text-[8px] font-black text-zinc-500 uppercase tracking-tighter">Secure</span>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
            <div>
              <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 ml-1">Email Address</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <UserIcon className="w-4 h-4 text-zinc-600 group-focus-within:text-blue-500 transition-colors" />
                </div>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl pl-12 pr-4 py-4 text-white font-bold outline-none focus:border-blue-500 transition-all"
                  placeholder="name@example.com"
                  required
                />
              </div>
            </div>

            {!isLogin && (
              <div>
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 ml-1">Invitation Code</label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <CheckCircle2 className="w-4 h-4 text-zinc-600 group-focus-within:text-blue-500 transition-colors" />
                  </div>
                  <input 
                    type="text" 
                    value={invitationCode}
                    onChange={(e) => setInvitationCode(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl pl-12 pr-4 py-4 text-white font-bold outline-none focus:border-blue-500 transition-all"
                    placeholder="Masukkan kode undangan"
                    required={!isLogin}
                  />
                </div>
                <div className="flex items-center gap-2 mt-2 ml-1">
                  <p className="text-[9px] text-zinc-600 font-bold uppercase tracking-tighter">Hubungi admin untuk mendapatkan kode</p>
                  <a 
                    href="https://wa.wizard.id/550865" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-500 px-2 py-1 rounded-full border border-emerald-500/20 transition-all group"
                  >
                    <svg className="w-3 h-3 fill-current" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.937 3.659 1.432 5.631 1.433h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                    <span className="text-[8px] font-black uppercase tracking-widest">WhatsApp Admin</span>
                  </a>
                </div>
              </div>
            )}

            <div>
              <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 ml-1">Password</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Lock className="w-4 h-4 text-zinc-600 group-focus-within:text-blue-500 transition-colors" />
                </div>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl pl-12 pr-4 py-4 text-white font-bold outline-none focus:border-blue-500 transition-all"
                  placeholder="••••••••"
                  required
                  minLength={6}
                />
              </div>
            </div>

            {successMessage && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                <p className="text-xs font-bold text-emerald-500">{successMessage}</p>
              </div>
            )}

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                <p className="text-xs font-bold text-red-500">{error}</p>
              </div>
            )}

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white py-5 rounded-2xl font-black uppercase tracking-widest transition-all shadow-xl shadow-blue-900/20 active:scale-[0.98] flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Sedang Memproses...</span>
                </div>
              ) : (isLogin ? 'Masuk Sekarang' : 'Daftar Akun')}
              {!loading && <LogIn className="w-4 h-4" />}
            </button>

            <div className="text-center mt-4">
              <button 
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setError('');
                  setSuccessMessage('');
                  setInvitationCode('');
                }}
                className="text-[10px] font-black text-zinc-500 hover:text-blue-500 uppercase tracking-widest transition-colors"
              >
                {isLogin ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Login'}
              </button>
            </div>
          </form>
        </div>

        <p className="text-center text-zinc-600 text-[10px] font-bold uppercase tracking-widest mt-8">
          created by : jalu sing garang
        </p>
      </div>
    </div>
  );
};

export default Login;
