
import { useState, FC, FormEvent, ChangeEvent, useMemo, memo, useCallback } from 'react';
import { Vocab, User } from '../types';
import { db } from '../services/db';

interface SetoranProps {
  onRefresh: () => void;
  vocabs: Vocab[];
  user: User | null;
}

type SetoranMode = 'biasa' | 'gambar' | 'massal';

// Memoized Vocab Card for performance
const VocabCard = memo(({ v, isAdmin, onEdit, onDelete, onDeleteImage }: { 
  v: Vocab, 
  isAdmin: boolean, 
  onEdit: (v: Vocab) => void, 
  onDelete: (id: string) => void,
  onDeleteImage: (id: string) => void
}) => (
  <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden group hover:border-blue-500/50 transition-all shadow-md hover:shadow-xl hover:shadow-blue-900/10">
    <div className="relative">
      {v.imageUrl && (
        <div className="h-40 overflow-hidden relative">
          <img src={v.imageUrl} alt={v.word} className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500" loading="lazy" />
          <button 
            onClick={() => onDeleteImage(v.id)}
            className="absolute top-2 right-2 bg-slate-950/80 backdrop-blur-md text-red-500 p-2 rounded-lg opacity-0 group-hover:opacity-100 transition-all hover:bg-red-500 hover:text-white"
            title="Hapus Gambar Saja"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </button>
        </div>
      )}
      <div className="p-5">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded ${v.chapterId ? 'bg-blue-600/20 text-blue-500' : 'bg-slate-800 text-slate-500'}`}>
              {v.chapterId ? `Bab ${v.chapterId}` : 'Tambahan'}
            </span>
          </div>
        </div>
        <h4 className="font-bold text-xl text-white truncate mb-1">{v.word}</h4>
        <p className="text-slate-400 font-medium text-sm truncate">{v.meaning}</p>
        
        {isAdmin && (
          <div className="flex mt-6 gap-2">
            <button 
              onClick={() => onEdit(v)}
              className="flex-1 flex items-center justify-center space-x-2 bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white py-2 rounded-xl text-xs font-bold transition-all border border-slate-700 hover:border-blue-500"
            >
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
              </svg>
              <span>Edit</span>
            </button>
            <button 
              onClick={() => onDelete(v.id)}
              className="flex-1 flex items-center justify-center space-x-2 bg-slate-800 hover:bg-red-950 text-slate-400 hover:text-red-400 py-2 rounded-xl text-xs font-bold transition-all border border-slate-700 hover:border-red-900"
            >
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
              <span>Hapus</span>
            </button>
          </div>
        )}
      </div>
    </div>
  </div>
));

// Memoized Vocab Grid to prevent list re-renders when typing in form
const VocabGrid = memo(({ vocabs, isAdmin, onEdit, onDelete, onDeleteImage }: { 
  vocabs: Vocab[], 
  isAdmin: boolean, 
  onEdit: (v: Vocab) => void, 
  onDelete: (id: string) => void,
  onDeleteImage: (id: string) => void
}) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    {vocabs.map((v) => (
      <VocabCard 
        key={v.id} 
        v={v} 
        isAdmin={isAdmin} 
        onEdit={onEdit} 
        onDelete={onDelete} 
        onDeleteImage={onDeleteImage} 
      />
    ))}
  </div>
));

const Setoran: FC<SetoranProps> = ({ onRefresh, vocabs, user }) => {
  const isAdmin = user?.role === 'admin';
  const [mode, setMode] = useState<SetoranMode>('biasa');
  const [word, setWord] = useState('');
  const [meaning, setMeaning] = useState('');
  const [chapterId, setChapterId] = useState<string>('');
  const [isChapterMode, setIsChapterMode] = useState(false);
  const [imageUrl, setImageUrl] = useState<string>('');
  const [massText, setMassText] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterChapter, setFilterChapter] = useState<string>('all');
  const [displayLimit, setDisplayLimit] = useState(24);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ text: string, type: 'error' | 'success' | 'info' } | null>(null);

  const filteredVocabs = useMemo(() => {
    return (filterChapter === 'all' 
      ? vocabs 
      : filterChapter === 'additional' 
        ? vocabs.filter(v => !v.chapterId)
        : vocabs.filter(v => v.chapterId === parseInt(filterChapter))
    ).filter(v => !v.isUnit);
  }, [vocabs, filterChapter]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    setStatusMsg({ text: "Sedang menghubungkan ke Supabase...", type: 'info' });
    
    // Safety timeout: stop loading after 20 seconds if no response
    const timeoutId = setTimeout(() => {
      setIsSubmitting(false);
      setStatusMsg({ text: "⚠️ Waktu Habis: Supabase tidak merespon. Cek koneksi internet atau validitas URL/Key.", type: 'error' });
    }, 20000);

    try {
      // Resolve final chapter value: if not in chapter mode, it's undefined (Additional)
      const finalChapterId = isChapterMode && chapterId ? parseInt(chapterId) : undefined;

      if (mode === 'massal' && !editingId) {
        const lines = massText.split('\n');
        const vocabsToAdd: any[] = [];
        
        for (const line of lines) {
          const parts = line.split(':');
          if (parts.length >= 2) {
            const w = parts[0].trim();
            const m = parts[1].trim();
            if (w && m) {
              vocabsToAdd.push({
                word: w,
                meaning: m,
                chapterId: finalChapterId,
              });
            }
          }
        }

        if (vocabsToAdd.length > 0) {
          await db.addVocabsBulk(vocabsToAdd);
          setMassText('');
          onRefresh();
          setStatusMsg({ text: `✅ ${vocabsToAdd.length} kosakata berhasil ditambahkan secara massal.`, type: 'success' });
        }
        clearTimeout(timeoutId);
        setIsSubmitting(false);
        return;
      }

      if (!word || !meaning) {
        clearTimeout(timeoutId);
        setIsSubmitting(false);
        setStatusMsg(null);
        return;
      }

      const data = {
        word,
        meaning,
        chapterId: finalChapterId,
        imageUrl: mode === 'gambar' ? (imageUrl || undefined) : undefined,
      };

      if (editingId) {
        await db.updateVocab(editingId, data);
        setEditingId(null);
      } else {
        await db.addVocab(data);
      }

      clearTimeout(timeoutId);
      resetForm();
      onRefresh();
      setStatusMsg({ text: "✅ Berhasil disimpan ke Supabase!", type: 'success' });
      
      // Clear success message after 3 seconds
      setTimeout(() => setStatusMsg(null), 3000);
    } catch (err: any) {
      clearTimeout(timeoutId);
      console.error("Submit error:", err);
      setStatusMsg({ 
        text: "❌ GAGAL: " + (err.message || "Terjadi kesalahan koneksi."), 
        type: 'error' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setWord('');
    setMeaning('');
    setChapterId('');
    setIsChapterMode(false);
    setImageUrl('');
    setMassText('');
    setEditingId(null);
  };

  const handleEdit = useCallback((v: Vocab) => {
    setEditingId(v.id);
    setMode(v.imageUrl ? 'gambar' : 'biasa');
    setWord(v.word);
    setMeaning(v.meaning);
    setChapterId(v.chapterId?.toString() || '');
    setIsChapterMode(!!v.chapterId);
    setImageUrl(v.imageUrl || '');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleDeleteItem = useCallback(async (id: string) => {
    if (confirm('Hapus seluruh kosakata ini?')) {
      await db.deleteVocab(id);
      onRefresh();
    }
  }, [onRefresh]);

  const handleDeleteAll = useCallback(async () => {
    const filteredCount = filteredVocabs.length;
    if (filteredCount === 0) return;

    let filterName = "Semua Materi";
    if (filterChapter === 'additional') filterName = "Kosakata Tambahan";
    else if (filterChapter !== 'all') filterName = `Bab ${filterChapter}`;

    const confirmMsg = filterChapter === 'all' 
      ? `HAPUS SEMUA DATA?\n\nAnda akan menghapus SELURUH ${filteredCount} kosakata dari aplikasi. Tindakan ini permanen.`
      : `HAPUS DATA ${filterName.toUpperCase()}?\n\nAnda akan menghapus ${filteredCount} kosakata khusus dari ${filterName}. Tindakan ini tidak dapat dibatalkan.`;

    if (confirm(confirmMsg)) {
      await db.deleteVocabsByFilter(filterChapter);
      onRefresh();
    }
  }, [filteredVocabs.length, filterChapter, onRefresh]);

  const handleDeleteImageOnly = useCallback(async (id: string) => {
    if (confirm('Hapus gambar saja dari kosakata ini?')) {
      await db.updateVocab(id, { imageUrl: undefined });
      onRefresh();
    }
  }, [onRefresh]);

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new Image();
        img.src = reader.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          // Compress to JPEG with 0.7 quality
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);
          setImageUrl(compressedDataUrl);
        };
      };
      reader.readAsDataURL(file);
    }
  };

  const handleChapterInputChange = (val: string) => {
    if (val === '') {
      setChapterId('');
      return;
    }
    const num = parseInt(val);
    if (!isNaN(num)) {
      if (num >= 1 && num <= 60) {
        setChapterId(num.toString());
      } else if (num > 60) {
        setChapterId('60');
      } else {
        setChapterId('1');
      }
    }
  };

  const visibleVocabs = useMemo(() => {
    return filteredVocabs.slice(0, displayLimit);
  }, [filteredVocabs, displayLimit]);

  // Dynamic button label based on current filter
  const getDeleteLabel = () => {
    if (filterChapter === 'all') return 'Hapus Semua';
    if (filterChapter === 'additional') return 'Hapus Tambahan';
    return `Hapus Bab ${filterChapter}`;
  };

  return (
    <div className="space-y-8 pb-20">
      {isAdmin && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="flex border-b border-slate-800 bg-slate-900/50">
          {(['biasa', 'gambar', 'massal'] as SetoranMode[]).map((m) => (
            <button
              key={m}
              disabled={!!editingId && m === 'massal'}
              onClick={() => { setMode(m); }}
              className={`flex-1 py-4 text-xs md:text-sm font-bold uppercase tracking-wider transition-all disabled:opacity-30 ${
                mode === m ? 'text-blue-500 bg-blue-500/10 border-b-2 border-blue-500' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {m === 'biasa' ? 'Setoran Biasa' : m === 'gambar' ? 'Setoran Gambar' : 'Setoran Massal'}
            </button>
          ))}
        </div>

        <div className="p-6">
          {statusMsg && (
            <div className={`mb-6 p-4 rounded-xl border flex items-center gap-3 ${
              statusMsg.type === 'error' ? 'bg-red-500/10 border-red-500/50 text-red-500' :
              statusMsg.type === 'success' ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-500' :
              'bg-blue-500/10 border-blue-500/50 text-blue-500'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                statusMsg.type === 'error' ? 'bg-red-500' :
                statusMsg.type === 'success' ? 'bg-emerald-500' :
                'bg-blue-500'
              }`} />
              <p className="text-xs font-bold uppercase tracking-wider">{statusMsg.text}</p>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                {mode !== 'massal' ? (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-1">Kosakata / Word</label>
                      <input 
                        type="text" 
                        value={word} 
                        onChange={(e) => setWord(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                        placeholder="Contoh: Apple"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-1">Arti / Meaning</label>
                      <input 
                        type="text" 
                        value={meaning} 
                        onChange={(e) => setMeaning(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                        placeholder="Contoh: Apel"
                        required
                      />
                    </div>
                  </>
                ) : (
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-400 mb-1">Input Massal (Format "kata : arti" per baris)</label>
                    <textarea 
                      value={massText}
                      onChange={(e) => setMassText(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all h-44 resize-none font-mono text-sm leading-relaxed"
                      placeholder={`apple : apel\nbanana : pisang\ncat : kucing`}
                      required
                    ></textarea>
                  </div>
                )}
                
                <div className={mode === 'massal' ? 'md:col-span-2' : ''}>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Penempatan Kosakata</label>
                  <div className="flex gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
                    <button 
                      type="button"
                      onClick={() => { setIsChapterMode(true); if(!chapterId) setChapterId('1'); }}
                      className={`flex-1 py-2.5 px-4 rounded-lg font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center ${isChapterMode ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                    >
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                      Pilih Bab
                    </button>
                    <button 
                      type="button"
                      onClick={() => { setIsChapterMode(false); }}
                      className={`flex-1 py-2.5 px-4 rounded-lg font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center ${!isChapterMode ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                    >
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                      Tambahan
                    </button>
                  </div>

                  {isChapterMode && (
                    <div className="mt-4">
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                          <span className="text-blue-500 font-black text-sm uppercase tracking-tighter">BAB</span>
                        </div>
                        <input 
                          type="number"
                          min="1"
                          max="60"
                          value={chapterId}
                          onChange={(e) => handleChapterInputChange(e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-14 pr-4 py-3 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-black text-xl"
                          placeholder="1-60"
                          required={isChapterMode}
                        />
                        <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none">
                          <span className="text-[10px] font-bold text-slate-500 group-focus-within:text-blue-400">INPUT MANUAL (1-60)</span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {!isChapterMode && (
                    <div className="mt-4 space-y-4">
                      <div className="p-4 bg-slate-800/30 border border-dashed border-slate-700 rounded-xl">
                        <p className="text-[10px] text-slate-500 italic text-center">Disimpan sebagai kosakata tambahan umum.</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              {mode === 'gambar' && (
                <div className="space-y-4">
                  <label className="block text-sm font-medium text-slate-400 mb-1">Visualisasi Gambar</label>
                  <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-700 rounded-xl p-4 bg-slate-800/50 hover:border-slate-500 transition-all min-h-[220px]">
                    {imageUrl ? (
                      <div className="relative group flex flex-col items-center">
                        <img src={imageUrl} alt="Preview" className="max-h-40 rounded-lg object-contain mb-3" />
                        <button 
                          type="button" 
                          onClick={() => setImageUrl('')}
                          className="flex items-center space-x-2 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-all"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                          <span>Hapus Gambar</span>
                        </button>
                      </div>
                    ) : (
                      <label className="cursor-pointer flex flex-col items-center w-full h-full justify-center group">
                        <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                          <svg className="w-8 h-8 text-slate-500 group-hover:text-blue-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                        </div>
                        <span className="text-sm text-slate-400 font-medium">Klik untuk Unggah Gambar</span>
                        <p className="text-[10px] text-slate-600 mt-1 uppercase tracking-tighter">JPG, PNG, WEBP</p>
                        <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                      </label>
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-4 pt-4">
              <button 
                type="submit" 
                disabled={isSubmitting}
                className={`flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 px-6 rounded-xl shadow-lg transition-all active:scale-95 flex items-center justify-center space-x-2 ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                )}
                <span>{isSubmitting ? 'Menyimpan...' : editingId ? 'Simpan Perubahan' : mode === 'massal' ? 'Proses Massal' : 'Simpan Kosakata'}</span>
              </button>
              {editingId && (
                <button 
                  type="button" 
                  onClick={resetForm}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-400 font-bold py-4 px-8 rounded-xl transition-all"
                >
                  Batal
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
      )}

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <h3 className="text-xl font-bold flex items-center">
            <span className="w-2 h-6 bg-blue-500 rounded-full mr-3"></span>
            Daftar Materi Tersimpan
          </h3>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-500 font-bold uppercase">Filter:</span>
              <select 
                value={filterChapter} 
                onChange={(e) => setFilterChapter(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 text-sm outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
              >
                <option value="all">Semua Materi</option>
                <option value="additional">Hanya Tambahan</option>
                {Array.from({ length: 60 }, (_, i) => (
                  <option key={i+1} value={i+1}>Bab {i+1}</option>
                ))}
              </select>
            </div>
            
            {isAdmin && (
              <button 
                onClick={handleDeleteAll}
                disabled={filteredVocabs.length === 0}
                className={`flex items-center space-x-2 px-4 py-2 bg-red-500/10 text-red-500 hover:bg-red-600 hover:text-white border border-red-500/20 rounded-xl transition-all font-bold text-xs ${filteredVocabs.length === 0 ? 'opacity-30 cursor-not-allowed grayscale' : ''}`}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                <span>{getDeleteLabel()}</span>
              </button>
            )}
          </div>
        </div>

        <VocabGrid 
          vocabs={visibleVocabs} 
          isAdmin={isAdmin} 
          onEdit={handleEdit} 
          onDelete={handleDeleteItem} 
          onDeleteImage={handleDeleteImageOnly} 
        />

        {filteredVocabs.length === 0 && (
          <div className="py-20 text-center text-zinc-600 bg-zinc-900/30 border-2 border-dashed border-zinc-800 rounded-3xl">
            <svg className="w-16 h-16 mx-auto mb-4 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
            <p className="font-medium">Belum ada kosakata di filter ini.</p>
            <p className="text-xs mt-1">Silakan tambahkan melalui form di atas.</p>
          </div>
        )}

        {filteredVocabs.length > displayLimit && (
          <div className="flex justify-center pt-8">
            <button 
              onClick={() => setDisplayLimit(prev => prev + 24)}
              className="bg-slate-800 hover:bg-blue-600 text-white font-bold py-3 px-10 rounded-xl transition-all border border-slate-700 hover:border-blue-500 shadow-lg"
            >
              Muat Lebih Banyak ({filteredVocabs.length - displayLimit} lagi)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Setoran;
