
import { useState, FC } from 'react';
import { Grammar as GrammarType, User } from '../types';
import { db } from '../services/db';
import { 
  Plus, 
  Search, 
  BookOpen, 
  Type, 
  Languages, 
  AlignLeft, 
  MessageSquare, 
  Layers, 
  Tag as TagIcon, 
  StickyNote, 
  Save, 
  X, 
  Edit3, 
  Trash2,
  ChevronRight
} from 'lucide-react';

interface GrammarProps {
  grammars: GrammarType[];
  onRefresh: () => void;
  user: User | null;
}

const Grammar: FC<GrammarProps> = ({ grammars, onRefresh, user }) => {
  const isAdmin = user?.role === 'admin';
  const [selectedGrammar, setSelectedGrammar] = useState<GrammarType | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterLevel, setFilterLevel] = useState<string>('all');
  
  const [title, setTitle] = useState('');
  const [meaning, setMeaning] = useState('');
  const [description, setDescription] = useState('');
  const [exampleSentence, setExampleSentence] = useState('');
  const [exampleExplanation, setExampleExplanation] = useState('');
  const [level, setLevel] = useState<string>('Umum');
  const [babNumber, setBabNumber] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [notes, setNotes] = useState('');

  const filteredGrammars = grammars.filter(g => {
    const matchesSearch = g.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      g.meaning.toLowerCase().includes(searchTerm.toLowerCase()) ||
      g.tags?.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (filterLevel === 'all') return matchesSearch;
    if (filterLevel === 'Umum') return matchesSearch && g.level === 'Umum';
    return matchesSearch && g.level === `Bab ${filterLevel}`;
  });

  const allTags = Array.from(new Set(grammars.flatMap(g => g.tags || [])));

  const handleAddTag = (tag: string) => {
    const trimmedTag = tag.trim();
    if (trimmedTag && !tags.includes(trimmedTag)) {
      setTags([...tags, trimmedTag]);
      setTagInput('');
    }
  };

  const handleSave = async () => {
    if (!title || !meaning) return;
    
    const finalLevel = level === 'Bab' ? `Bab ${babNumber}` : 'Umum';
    
    const grammarData = { 
      title, 
      meaning, 
      description, 
      exampleSentence, 
      exampleExplanation, 
      level: finalLevel, 
      tags, 
      notes 
    };

    if (isEditing && selectedGrammar) {
      await db.updateGrammar(selectedGrammar.id, grammarData);
    } else {
      await db.addGrammar(grammarData);
    }
    
    setIsAdding(false);
    setIsEditing(false);
    setSelectedGrammar(null);
    onRefresh();
  };

  const handleSelectGrammar = (g: GrammarType) => {
    setSelectedGrammar(g);
    // Scroll to detail on mobile for better UX
    setTimeout(() => {
      const detailElement = document.getElementById('grammar-detail');
      if (detailElement && window.innerWidth < 768) {
        detailElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Hapus grammar ini?')) {
      await db.deleteGrammar(id);
      setSelectedGrammar(null);
      onRefresh();
    }
  };

  const handleDeleteAll = async () => {
    const filteredCount = filteredGrammars.length;
    if (filteredCount === 0) return;

    let filterName = "Semua Materi";
    if (filterLevel === 'Umum') filterName = "Grammar Umum";
    else if (filterLevel !== 'all') filterName = `Bab ${filterLevel}`;

    const confirmMsg = filterLevel === 'all' 
      ? `HAPUS SEMUA GRAMMAR?\n\nAnda akan menghapus SELURUH ${filteredCount} materi grammar. Tindakan ini permanen.`
      : `HAPUS DATA ${filterName.toUpperCase()}?\n\nAnda akan menghapus ${filteredCount} materi grammar dari ${filterName}. Tindakan ini tidak dapat dibatalkan.`;

    if (confirm(confirmMsg)) {
      const filterValue = filterLevel === 'all' ? 'all' : filterLevel === 'Umum' ? 'Umum' : `Bab ${filterLevel}`;
      await db.deleteGrammarsByFilter(filterValue);
      setSelectedGrammar(null);
      onRefresh();
    }
  };

  if (isAdding || isEditing) {
    return (
      <div className="max-w-6xl mx-auto space-y-8 pb-20">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-black text-white tracking-tight flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-900/20">
                {isEditing ? <Edit3 className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
              </div>
              {isEditing ? 'Edit Materi' : 'Tambah Materi'} Grammar
            </h2>
            <p className="text-slate-500 mt-1 ml-13">Lengkapi detail tatabahasa Korea untuk dipelajari nanti.</p>
          </div>
          <button 
            onClick={() => { setIsAdding(false); setIsEditing(false); }}
            className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-500 hover:text-white"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Section 1: Basic Info */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8 space-y-6 shadow-xl">
              <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase tracking-widest mb-2">
                <Type className="w-4 h-4" /> Informasi Dasar
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 ml-1">Tatabahasa</label>
                  <div className="relative group">
                    <input 
                      type="text" 
                      value={title} 
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all group-hover:border-slate-700"
                      placeholder="Contoh: ~고 싶다"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 ml-1">Arti / Makna</label>
                  <div className="relative group">
                    <input 
                      type="text" 
                      value={meaning} 
                      onChange={(e) => setMeaning(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all group-hover:border-slate-700"
                      placeholder="Contoh: Ingin"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-300 ml-1 flex items-center gap-2">
                  <AlignLeft className="w-4 h-4 text-slate-500" /> Penjelasan Singkat
                </label>
                <textarea 
                  value={description} 
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white outline-none h-32 resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all group-hover:border-slate-700"
                  placeholder="Jelaskan cara penggunaan tatabahasa ini secara singkat..."
                />
              </div>
            </div>

            {/* Section 2: Examples */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8 space-y-6 shadow-xl">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-widest mb-2">
                <MessageSquare className="w-4 h-4" /> Contoh Penggunaan
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 ml-1">Kalimat Contoh (Korea)</label>
                  <input 
                    type="text" 
                    value={exampleSentence} 
                    onChange={(e) => setExampleSentence(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                    placeholder="Contoh: 한국에 가고 싶어요"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 ml-1">Terjemahan Contoh</label>
                  <input 
                    type="text" 
                    value={exampleExplanation} 
                    onChange={(e) => setExampleExplanation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                    placeholder="Contoh: Saya ingin pergi ke Korea"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {/* Section 3: Level & Tags */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 space-y-6 shadow-xl">
              <div className="space-y-4">
                <label className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Layers className="w-4 h-4" /> Tingkatan
                </label>
                <div className="flex p-1 bg-slate-950 rounded-2xl border border-slate-800">
                  <button 
                    onClick={() => setLevel('Umum')}
                    className={`flex-1 py-3 rounded-xl font-bold transition-all ${level === 'Umum' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    Umum
                  </button>
                  <button 
                    onClick={() => setLevel('Bab')}
                    className={`flex-1 py-3 rounded-xl font-bold transition-all ${level === 'Bab' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    Bab
                  </button>
                </div>
                {level === 'Bab' && (
                  <div>
                    <input 
                      type="number" 
                      value={babNumber} 
                      onChange={(e) => setBabNumber(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Nomor Bab (1-60)"
                    />
                  </div>
                )}
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-800">
                <label className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <TagIcon className="w-4 h-4" /> Label / Tag
                </label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={tagInput} 
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAddTag(tagInput)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Ketik tag..."
                  />
                  <button onClick={() => handleAddTag(tagInput)} className="bg-slate-800 hover:bg-slate-700 px-4 rounded-xl transition-all text-xs font-bold">Add</button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {tags.map((tag, idx) => (
                    <span key={`${tag}-${idx}`} className="bg-blue-600/10 text-blue-400 px-3 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 border border-blue-500/20">
                      {tag}
                      <button onClick={() => setTags(tags.filter((_, i) => i !== idx))} className="hover:text-white"><X className="w-3 h-3" /></button>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Section 4: Notes */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
              <label className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <StickyNote className="w-4 h-4" /> Catatan Tambahan
              </label>
              <textarea 
                value={notes} 
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-3 text-white outline-none h-32 resize-none focus:ring-2 focus:ring-blue-500 transition-all"
                placeholder="Tips atau catatan penting lainnya..."
              />
            </div>

            <div className="flex flex-col gap-3 pt-4">
              <button 
                onClick={handleSave} 
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-900/20 transition-all active:scale-95 flex items-center justify-center gap-2 text-lg"
              >
                <Save className="w-6 h-6" /> Simpan Materi
              </button>
              <button 
                onClick={() => { setIsAdding(false); setIsEditing(false); }} 
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-400 font-bold py-4 rounded-2xl transition-all"
              >
                Batalkan
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col md:flex-row gap-6 overflow-hidden pb-10">
      {/* List Area */}
      <div className="md:w-1/5 flex flex-col bg-slate-900 border border-slate-800 rounded-3xl p-5 overflow-hidden shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-black text-xl flex items-center gap-2 text-white">
             <div className="w-2 h-6 bg-blue-500 rounded-full"></div>
             Materi Grammar
          </h3>
          {isAdmin && (
            <button 
              onClick={() => { 
                setIsAdding(true); 
                setTitle(''); 
                setMeaning('');
                setDescription('');
                setExampleSentence('');
                setExampleExplanation('');
                setLevel('Umum');
                setBabNumber('');
                setTags([]);
                setNotes('');
              }}
              className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center hover:bg-blue-500 transition-all shadow-lg shadow-blue-900/20 active:scale-90"
            >
              <Plus className="w-6 h-6 text-white" />
            </button>
          )}
        </div>
        
        <div className="relative mb-4">
          <input 
            type="text" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Cari tatabahasa..."
            className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-4 py-3 text-sm text-white outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
          <Search className="w-5 h-5 text-slate-500 absolute left-4 top-1/2 -translate-y-1/2" />
        </div>

        <div className="space-y-3 mb-6">
          <div className="flex items-center space-x-2">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Filter:</span>
            <select 
              value={filterLevel} 
              onChange={(e) => setFilterLevel(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
            >
              <option value="all">Semua</option>
              <option value="Umum">Umum</option>
              {Array.from({ length: 60 }, (_, i) => (
                <option key={i+1} value={i+1}>Bab {i+1}</option>
              ))}
            </select>
          </div>
          
          {isAdmin && (
            <button 
              onClick={handleDeleteAll}
              disabled={filteredGrammars.length === 0}
              className={`w-full flex items-center justify-center space-x-2 px-4 py-2 bg-red-500/10 text-red-500 hover:bg-red-600 hover:text-white border border-red-500/20 rounded-xl transition-all font-bold text-[10px] uppercase tracking-widest ${filteredGrammars.length === 0 ? 'opacity-30 cursor-not-allowed grayscale' : ''}`}
            >
              <Trash2 className="w-3 h-3" />
              <span>Hapus Filtered</span>
            </button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-1 custom-scrollbar">
          {filteredGrammars.map(g => (
            <button 
              key={g.id}
              onClick={() => handleSelectGrammar(g)}
              className={`w-full text-left p-5 rounded-2xl border transition-all group ${
                selectedGrammar?.id === g.id 
                  ? 'bg-blue-600/10 border-blue-500 text-blue-400 shadow-inner' 
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-600 hover:bg-slate-900'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <h5 className="font-black text-lg truncate group-hover:text-white transition-colors">{g.title}</h5>
                <ChevronRight className={`w-4 h-4 transition-transform ${selectedGrammar?.id === g.id ? 'rotate-90 text-blue-400' : 'text-slate-700 group-hover:translate-x-1'}`} />
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-[9px] px-2 py-0.5 rounded-full uppercase font-black tracking-tighter ${g.level === 'Umum' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/20' : 'bg-purple-500/20 text-purple-400 border border-purple-500/20'}`}>
                  {g.level}
                </span>
                <p className="text-xs truncate opacity-60 flex-1 font-medium italic">{g.meaning}</p>
              </div>
            </button>
          ))}
          {filteredGrammars.length === 0 && (
            <div className="py-24 text-center text-slate-600 text-sm flex flex-col items-center">
              <div className="w-20 h-20 bg-slate-950 rounded-full flex items-center justify-center mb-4 border border-slate-800">
                <Search className="w-8 h-8 opacity-20" />
              </div>
              <span className="font-bold opacity-40">{searchTerm ? 'Grammar tidak ditemukan.' : 'Belum ada materi grammar.'}</span>
            </div>
          )}
        </div>
      </div>

      {/* Detail Area */}
      <div id="grammar-detail" className="flex-1 flex flex-col overflow-hidden min-w-0">
        {selectedGrammar ? (
          <div className="flex-1 bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-12 overflow-y-auto shadow-2xl custom-scrollbar">
            <div className="flex flex-col lg:flex-row lg:items-start justify-between mb-8 border-b border-slate-800 pb-8 gap-6">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-4 flex-wrap">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${selectedGrammar.level === 'Umum' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/20' : 'bg-purple-500/20 text-purple-400 border border-purple-500/20'}`}>
                    {selectedGrammar.level}
                  </span>
                  <div className="flex gap-1">
                    {selectedGrammar.tags?.map((tag, idx) => (
                      <span key={`${tag}-${idx}`} className="px-2 py-0.5 rounded-md text-[9px] bg-slate-800 text-slate-500 border border-slate-700 font-bold">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
                <h2 className="text-4xl md:text-6xl font-black text-white tracking-tighter break-words">{selectedGrammar.title}</h2>
              </div>
              {isAdmin && (
                <div className="flex gap-2 shrink-0">
                  <button 
                    onClick={() => { 
                      setIsEditing(true); 
                      setTitle(selectedGrammar.title); 
                      setMeaning(selectedGrammar.meaning);
                      setDescription(selectedGrammar.description);
                      setExampleSentence(selectedGrammar.exampleSentence);
                      setExampleExplanation(selectedGrammar.exampleExplanation);
                      if (selectedGrammar.level.startsWith('Bab')) {
                        setLevel('Bab');
                        setBabNumber(selectedGrammar.level.replace('Bab ', ''));
                      } else {
                        setLevel('Umum');
                        setBabNumber('');
                      }
                      setTags(selectedGrammar.tags || []);
                      setNotes(selectedGrammar.notes);
                    }}
                    className="w-12 h-12 bg-slate-950 rounded-2xl flex items-center justify-center hover:bg-blue-600 text-slate-500 hover:text-white transition-all border border-slate-800 shadow-lg"
                    title="Edit"
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => handleDelete(selectedGrammar.id)}
                    className="w-12 h-12 bg-slate-950 rounded-2xl flex items-center justify-center hover:bg-red-600 text-slate-500 hover:text-white transition-all border border-slate-800 shadow-lg"
                    title="Hapus"
                  >
                     <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              <div className="space-y-10">
                <div>
                  <h3 className="text-xs font-black text-blue-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                    <Languages className="w-4 h-4" /> Arti & Makna
                  </h3>
                  <p className="text-3xl text-white font-bold leading-tight">{selectedGrammar.meaning}</p>
                </div>

                {selectedGrammar.description && (
                  <div>
                    <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                      <AlignLeft className="w-4 h-4" /> Penjelasan Penggunaan
                    </h3>
                    <div className="bg-slate-950/50 border border-slate-800 rounded-3xl p-6">
                      <p className="text-slate-300 whitespace-pre-wrap leading-relaxed font-medium">{selectedGrammar.description}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-10">
                <div className="bg-emerald-600/5 border border-emerald-500/20 rounded-[2.5rem] p-8 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                    <MessageSquare className="w-32 h-32 -mr-10 -mt-10" />
                  </div>
                  <h3 className="text-xs font-black text-emerald-500 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" /> Contoh Kalimat
                  </h3>
                  <div className="space-y-4 relative z-10">
                    <p className="text-3xl text-white font-black italic leading-tight">"{selectedGrammar.exampleSentence}"</p>
                    <div className="w-12 h-1 bg-emerald-500/30 rounded-full"></div>
                    <p className="text-emerald-400/80 text-xl font-medium">{selectedGrammar.exampleExplanation}</p>
                  </div>
                </div>

                {selectedGrammar.notes && (
                  <div className="bg-amber-500/5 border border-amber-500/20 p-8 rounded-[2.5rem] relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-5">
                      <StickyNote className="w-24 h-24 -mr-6 -mt-6" />
                    </div>
                    <h3 className="text-xs font-black text-amber-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                      <StickyNote className="w-4 h-4" /> Tips & Catatan
                    </h3>
                    <p className="text-slate-300 italic leading-relaxed relative z-10 font-medium">{selectedGrammar.notes}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 bg-slate-950/30 border-2 border-dashed border-slate-800 rounded-[3rem] flex flex-col items-center justify-center text-slate-600 p-10 text-center">
             <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center mb-6 border border-slate-800 shadow-inner">
               <BookOpen className="w-10 h-10 opacity-20" />
             </div>
            <h3 className="text-2xl font-black text-slate-400 mb-3">Pilih Materi Grammar</h3>
            <p className="max-w-sm text-slate-500 font-medium leading-relaxed">Klik salah satu materi di sidebar untuk melihat penjelasan detail, contoh kalimat, dan tips penggunaan.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Grammar;
