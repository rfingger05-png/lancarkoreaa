
import { FC, ReactNode, useState } from 'react';
import { NAV_ITEMS } from '../constants';
import { User, LogOut, Menu, X } from 'lucide-react';
import { User as UserType } from '../types';

interface LayoutProps {
  children: ReactNode;
  activeTab: string;
  user: UserType | null;
  onTabChange: (id: string) => void;
  onLogout: () => void;
}

const Layout: FC<LayoutProps> = ({ children, activeTab, user, onTabChange, onLogout }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleTabClick = (id: string) => {
    onTabChange(id);
    setIsMenuOpen(false);
  };

  const visibleNavItems = NAV_ITEMS.filter(item => {
    if (item.id === 'admin') return user?.role === 'admin';
    return true;
  });

  return (
    <div className="flex h-screen bg-[#0a0a0a] text-zinc-50 font-sans">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 border-r border-zinc-800/50 bg-[#0f0f0f]">
        <div className="p-8">
          <h1 className="text-2xl font-black text-blue-500 tracking-tighter uppercase italic">LANCAR <span className="text-white">KOREA</span></h1>
          <p className="text-[10px] text-zinc-500 font-bold tracking-[0.2em] mt-1">VOCAB & GRAMMAR</p>
        </div>
        <nav className="flex-1 px-4 space-y-1">
          {visibleNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex items-center w-full px-4 py-3 rounded-xl transition-all group ${
                activeTab === item.id 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' 
                  : 'text-zinc-500 hover:bg-zinc-800/50 hover:text-zinc-200'
              }`}
            >
              <svg className={`w-5 h-5 mr-3 transition-colors ${activeTab === item.id ? 'text-white' : 'text-zinc-600 group-hover:text-zinc-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
              </svg>
              <span className="font-bold text-sm tracking-tight">{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="p-6 mt-auto space-y-4">
          {user && (
            <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between group">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest leading-none mb-1">Logged in as</p>
                  <p className="text-xs font-bold text-white truncate max-w-[120px]">{user.email}</p>
                </div>
              </div>
              <button 
                onClick={onLogout}
                className="p-2 text-zinc-600 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
          <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/50 backdrop-blur-sm">
            <p className="text-[10px] font-black text-zinc-600 uppercase tracking-widest mb-2">System Status</p>
            <div className="space-y-2">
              <p className="text-xs font-bold text-emerald-400 flex items-center">
                <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></span>
                App Operational
              </p>
              <p className={`text-xs font-bold flex items-center ${!!import.meta.env.VITE_SUPABASE_URL ? 'text-blue-400' : 'text-amber-500'}`}>
                <span className={`w-2 h-2 rounded-full mr-2 ${!!import.meta.env.VITE_SUPABASE_URL ? 'bg-blue-500' : 'bg-amber-500'}`}></span>
                {!!import.meta.env.VITE_SUPABASE_URL ? 'Supabase Connected' : 'Supabase Disconnected'}
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        <header className="md:hidden flex items-center justify-between p-5 border-b border-zinc-800 bg-[#0a0a0a]/90 backdrop-blur-2xl sticky top-0 z-[60]">
          <div className="flex items-center gap-4 ml-2">
            <h1 className="text-xl font-black text-blue-500 tracking-tighter italic uppercase">LANCAR KOREA</h1>
            {user && (
              <span className="text-[9px] font-black bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded tracking-widest truncate max-w-[100px]">
                {user.email}
              </span>
            )}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-end gap-1 mr-2">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" title="App Operational"></div>
              <div className={`w-1.5 h-1.5 rounded-full ${!!import.meta.env.VITE_SUPABASE_URL ? 'bg-blue-500' : 'bg-amber-500'}`} title={!!import.meta.env.VITE_SUPABASE_URL ? 'Supabase Connected' : 'Supabase Disconnected'}></div>
            </div>
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-white active:scale-95 transition-all"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </header>

        {/* Mobile Menu Overlay */}
        {isMenuOpen && (
          <div className="md:hidden fixed inset-0 z-[55] bg-black/60 backdrop-blur-md">
            <div className="absolute top-[73px] left-0 right-0 bg-[#0f0f0f] border-b border-zinc-800 p-6">
              <nav className="grid grid-cols-2 gap-3">
                {visibleNavItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleTabClick(item.id)}
                    className={`flex items-center p-4 rounded-2xl transition-all border ${
                      activeTab === item.id 
                        ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/40' 
                        : 'bg-zinc-900/50 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <svg className={`w-5 h-5 mr-3 ${activeTab === item.id ? 'text-white' : 'text-zinc-500'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
                    </svg>
                    <span className="font-bold text-xs uppercase tracking-tight">{item.label}</span>
                  </button>
                ))}
              </nav>
              <div className="mt-6 pt-6 border-t border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-600/10 rounded-xl flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest leading-none mb-1">Signed in as</p>
                    <p className="text-sm font-bold text-white truncate max-w-[150px]">{user?.email}</p>
                  </div>
                </div>
                <button 
                  onClick={() => { onLogout(); setIsMenuOpen(false); }}
                  className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-500 rounded-xl text-xs font-bold hover:bg-red-500 hover:text-white transition-all"
                >
                  <LogOut className="w-4 h-4" />
                  LOGOUT
                </button>
              </div>
            </div>
          </div>
        )}
        
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 md:p-10 custom-scrollbar">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Layout;
