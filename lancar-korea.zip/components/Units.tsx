
import { useState, FC, FormEvent } from 'react';
import { Vocab, User } from '../types';
import { db } from '../services/db';
import { 
  Hash, 
  Search, 
  Layers, 
  ChevronRight,
  Info,
  Play,
  Plus,
  X,
  Save,
  Trash2
} from 'lucide-react';

interface UnitsProps {
  vocabs: Vocab[];
  onTabChange: (id: string) => void;
  onRefresh: () => void;
  user: User | null;
}

const Units: FC<UnitsProps> = ({ vocabs, onTabChange, onRefresh, user }) => {
  const isAdmin = user?.role === 'admin';
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'native' | 'sino'>('all');
  const [isAdding, setIsAdding] = useState(false);
  const [addMode, setAddMode] = useState<'single' | 'mass'>('single');
  const [word, setWord] = useState('');
  const [meaning, setMeaning] = useState('');
  const [unitType, setUnitType] = useState<'native' | 'sino'>('native');
  const [massText, setMassText] = useState('');

  const unitVocabs = vocabs.filter(v => v.isUnit);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (addMode === 'mass') {
      const lines = massText.split('\n');
      let count = 0;
      const promises = [];
      for (const line of lines) {
        const parts = line.split(':');
        if (parts.length >= 2) {
          const w = parts[0].trim();
          const m = parts[1].trim();
          if (w && m) {
            promises.push(db.addVocab({
              word: w,
              meaning: m,
              isUnit: true,
              unitType
            }));
            count++;
          }
        }
      }
      if (count > 0) {
        await Promise.all(promises);
        alert(`${count} satuan berhasil ditambahkan!`);
        setMassText('');
        setIsAdding(false);
        onRefresh();
      }
      return;
    }

    if (!word || !meaning) return;

    await db.addVocab({
      word,
      meaning,
      isUnit: true,
      unitType
    });

    setWord('');
    setMeaning('');
    setIsAdding(false);
    onRefresh();
  };

  const handleDelete = async (id: string) => {
    if (confirm('Hapus satuan ini?')) {
      await db.deleteVocab(id);
      onRefresh();
    }
  };

  const handleDeleteAll = async () => {
    if (unitVocabs.length === 0) return;
    if (confirm(`Hapus SEMUA (${unitVocabs.length}) satuan benda? Tindakan ini tidak bisa dibatalkan!`)) {
      const promises = unitVocabs.map(v => db.deleteVocab(v.id));
      await Promise.all(promises);
      alert('Semua satuan benda telah dihapus.');
      onRefresh();
    }
  };
  
  const filteredUnits = unitVocabs.filter(v => {
    const matchesSearch = v.word.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         v.meaning.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || v.unitType === filterType;
    return matchesSearch && matchesType;
  });

  const nativeCount = unitVocabs.filter(v => v.unitType === 'native').length;
  const sinoCount = unitVocabs.filter(v => v.unitType === 'sino').length;

  return (
    <div className="flex flex-col space-y-6 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter uppercase italic">
            Satuan <span className="text-blue-500">Benda</span>
          </h2>
          <p className="text-xs text-zinc-500 font-bold tracking-widest mt-1 uppercase">
            Unit perhitungan dalam bahasa Korea
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex bg-zinc-900 p-1 rounded-xl border border-zinc-800">
            {isAdmin && (
              <>
                <button
                  onClick={() => setIsAdding(!isAdding)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                    isAdding 
                      ? 'bg-zinc-800 text-zinc-400' 
                      : 'bg-blue-600 text-white shadow-lg shadow-blue-900/20'
                  }`}
                >
                  {isAdding ? <X className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                  {isAdding ? 'Batal' : 'Tambah'}
                </button>
                {unitVocabs.length > 0 && (
                  <button
                    onClick={handleDeleteAll}
                    className="flex items-center gap-2 px-3 py-2 text-red-500 hover:bg-red-500/10 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all"
                  >
                    <Trash2 className="w-3 h-3" />
                    Hapus Semua
                  </button>
                )}
              </>
            )}
            <button
              onClick={() => onTabChange('practice')}
              className="flex items-center gap-2 px-3 py-2 text-zinc-500 hover:text-emerald-500 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all"
            >
              <Play className="w-3 h-3 fill-current" />
              Latihan
            </button>
          </div>

          <div className="flex flex-wrap bg-zinc-900 p-1 rounded-xl border border-zinc-800 gap-1">
            {(['all', 'native', 'sino'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-3 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                  filterType === type 
                    ? 'bg-zinc-800 text-white' 
                    : 'text-zinc-600 hover:text-zinc-400'
                }`}
              >
                {type === 'all' ? 'Semua' : type === 'native' ? 'Asli' : 'Sino'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/50 backdrop-blur-sm flex items-center justify-between">
          <div>
            <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-1">Total Satuan</p>
            <p className="text-2xl font-black text-white">{unitVocabs.length}</p>
          </div>
          <Hash className="w-8 h-8 text-zinc-800" />
        </div>
        <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/50 backdrop-blur-sm flex items-center justify-between">
          <div>
            <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest mb-1">Asli Korea</p>
            <p className="text-2xl font-black text-white">{nativeCount}</p>
          </div>
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
            <span className="text-emerald-500 font-black text-xs">A</span>
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-zinc-900/50 border border-zinc-800/50 backdrop-blur-sm flex items-center justify-between">
          <div>
            <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1">Sino Korea</p>
            <p className="text-2xl font-black text-white">{sinoCount}</p>
          </div>
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
            <span className="text-blue-500 font-black text-xs">S</span>
          </div>
        </div>
      </div>

      {isAdding && (
        <form 
          onSubmit={handleSubmit}
          className="bg-zinc-900 border border-blue-500/30 rounded-2xl p-6 shadow-2xl"
        >
          <div className="flex items-center gap-4 mb-6 p-1 bg-zinc-950 rounded-xl border border-zinc-800 w-fit">
            <button
              type="button"
              onClick={() => setAddMode('single')}
              className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                addMode === 'single' ? 'bg-zinc-800 text-white' : 'text-zinc-600'
              }`}
            >
              Satu per Satu
            </button>
            <button
              type="button"
              onClick={() => setAddMode('mass')}
              className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                addMode === 'mass' ? 'bg-zinc-800 text-white' : 'text-zinc-600'
              }`}
            >
              Setor Massal
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {addMode === 'single' ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2">Satuan (Korea)</label>
                  <input 
                    type="text"
                    value={word}
                    onChange={(e) => setWord(e.target.value)}
                    placeholder="Contoh: 개"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-blue-500 transition-all"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2">Arti (Indonesia)</label>
                  <input 
                    type="text"
                    value={meaning}
                    onChange={(e) => setMeaning(e.target.value)}
                    placeholder="Contoh: Buah"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-blue-500 transition-all"
                    required
                  />
                </div>
              </div>
            ) : (
              <div className="md:col-span-1">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2">Input Massal (Format "kata : arti" per baris)</label>
                <textarea 
                  value={massText}
                  onChange={(e) => setMassText(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-blue-500 transition-all h-32 resize-none"
                  placeholder={`개 : buah\n명 : orang\n마리 : ekor`}
                  required
                ></textarea>
              </div>
            )}
            
            <div className="space-y-4">
              <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2">Sistem Bilangan (Berlaku untuk semua input)</label>
              <div className="grid grid-cols-2 gap-2 p-1 bg-zinc-950 rounded-xl border border-zinc-800">
                <button
                  type="button"
                  onClick={() => setUnitType('native')}
                  className={`py-3 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                    unitType === 'native' ? 'bg-emerald-600 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  Asli Korea
                </button>
                <button
                  type="button"
                  onClick={() => setUnitType('sino')}
                  className={`py-3 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                    unitType === 'sino' ? 'bg-blue-600 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  Sino Korea
                </button>
              </div>
              
              <div className="pt-2">
                <button 
                  type="submit"
                  className="w-full bg-white text-black hover:bg-zinc-200 py-4 rounded-xl font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-xl"
                >
                  <Save className="w-4 h-4" />
                  Simpan Satuan
                </button>
              </div>
            </div>
          </div>
        </form>
      )}

      <div className="relative group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-600 group-focus-within:text-blue-500 transition-colors" />
        <input 
          type="text"
          placeholder="Cari satuan atau arti..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-4 pl-12 pr-4 text-white font-medium outline-none focus:border-blue-500/50 transition-all placeholder:text-zinc-700"
        />
      </div>

      {filteredUnits.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center opacity-30 grayscale">
          <Layers className="w-16 h-16 mb-4" />
          <p className="text-lg font-black uppercase tracking-tighter">Tidak ada satuan ditemukan</p>
          <p className="text-sm font-medium">Coba kata kunci lain atau tambahkan menggunakan tombol di atas</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredUnits.map((unit) => (
            <div 
              key={unit.id}
              className="group bg-zinc-900 border border-zinc-800 rounded-2xl p-5 hover:border-blue-500/30 transition-all relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-3">
                <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest ${
                  unit.unitType === 'native' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-blue-500/10 text-blue-500'
                }`}>
                  {unit.unitType === 'native' ? 'Asli' : 'Sino'}
                </span>
              </div>

              <div className="flex flex-col h-full">
                <h3 className="text-3xl font-black text-white tracking-tighter mb-1 group-hover:text-blue-400 transition-colors">
                  {unit.word}
                </h3>
                <div className="flex items-center text-zinc-500 font-bold text-sm mb-4">
                  <ChevronRight className="w-4 h-4 text-blue-500 mr-1" />
                  {unit.meaning}
                </div>
                
                <div className="mt-auto pt-4 border-t border-zinc-800/50 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Info className="w-3 h-3 text-zinc-600" />
                    <span className="text-[9px] font-black text-zinc-600 uppercase tracking-widest">
                      {unit.unitType === 'native' ? 'Gunakan angka asli' : 'Gunakan angka sino'}
                    </span>
                  </div>
                  {isAdmin && (
                    <button 
                      onClick={() => handleDelete(unit.id)}
                      className="p-2 text-zinc-700 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Units;
