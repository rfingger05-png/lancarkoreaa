
import { useState, FC } from 'react';
import { AppState, PracticeHistory } from '../types';

interface DashboardProps {
  state: AppState;
}

const Dashboard: FC<DashboardProps> = ({ state }) => {
  const [selectedChHistory, setSelectedChHistory] = useState<number | 'additional' | null>(null);

  const totalVocab = state.vocabs.length;
  const totalImages = state.vocabs.filter(v => !!v.imageUrl).length;
  const totalGrammar = state.grammars.length;
  
  const chapterProgress = Array.from({ length: 60 }, (_, i) => {
    const chId = i + 1;
    const vocabCount = state.vocabs.filter(v => v.chapterId === chId).length;
    const progressPercent = state.progress[chId] || 0;
    return { chId, count: vocabCount, progress: progressPercent };
  });

  const activeChapters = chapterProgress.filter(cp => cp.count > 0).length;
  
  // Calculate average score from all history attempts
  const totalHistoryScores = state.history.reduce((acc, h) => acc + (h.score / h.total), 0);
  const avgProgress = state.history.length > 0 
    ? Math.round((totalHistoryScores / state.history.length) * 100) 
    : 0;

  const getHistoryFor = (id: number | 'additional'): PracticeHistory[] => {
    return state.history
      .filter(h => {
        if (id === 'additional') {
          return h.includeAdditional && h.chapterIds.length === 0;
        }
        return h.chapterIds.includes(id);
      })
      .sort((a, b) => b.timestamp - a.timestamp);
  };

  const formatDate = (ts: number) => {
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(ts));
  };

  const selectedHistories = selectedChHistory !== null ? getHistoryFor(selectedChHistory) : [];

  const recentVocabs = [...state.vocabs].sort((a, b) => {
    const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return dateB - dateA;
  }).slice(0, 5);

  return (
    <div className="flex flex-col space-y-6 pb-20">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-6 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-800 border border-blue-500 shadow-xl">
          <p className="text-blue-100 text-xs font-bold uppercase tracking-wider">Total Kosakata</p>
          <h3 className="text-4xl font-black mt-2">{totalVocab}</h3>
          <p className="text-blue-200 text-[10px] mt-1 font-medium">Total item tersimpan</p>
        </div>
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg">
          <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Total Gambar</p>
          <h3 className="text-4xl font-black mt-2 text-emerald-400">{totalImages}</h3>
          <p className="text-slate-600 text-[10px] mt-1 font-medium">Total visualisasi</p>
        </div>
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg">
          <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Total Grammar</p>
          <h3 className="text-4xl font-black mt-2 text-purple-400">{totalGrammar}</h3>
          <p className="text-slate-600 text-[10px] mt-1 font-medium">Total materi</p>
        </div>
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg">
          <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Rata-rata Skor</p>
          <h3 className="text-4xl font-black mt-2 text-blue-400">{avgProgress}<span className="text-slate-600 text-2xl font-normal">%</span></h3>
          <p className="text-slate-600 text-[10px] mt-1 font-medium">Berdasarkan latihan Anda</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-6">
            <h4 className="text-lg font-semibold mb-2 flex items-center justify-between">
              <div className="flex items-center">
                <span className="w-1.5 h-6 bg-blue-500 rounded-full mr-3"></span>
                Visualisasi Progress Bab
              </div>
              <button 
                onClick={() => setSelectedChHistory('additional')}
                className={`text-[10px] font-bold px-3 py-1 rounded-full transition-all ${selectedChHistory === 'additional' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-500 hover:text-slate-300'}`}
              >
                TAMBAHAN
              </button>
            </h4>
            <p className="text-xs text-slate-500 mb-4">Kotak bercahaya biru tua memiliki konten. Titik biru terang di bawah angka menandakan Anda sudah pernah berlatih bab tersebut.</p>
            <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-10 gap-2">
              {chapterProgress.map((cp) => (
                <button 
                  key={cp.chId} 
                  onClick={() => setSelectedChHistory(cp.chId)}
                  className={`aspect-square rounded-lg flex flex-col items-center justify-center border transition-all relative outline-none focus:ring-2 focus:ring-blue-500/50 ${
                    selectedChHistory === cp.chId ? 'ring-2 ring-blue-500 border-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : ''
                  } ${
                    cp.count > 0 
                      ? 'bg-blue-600/20 border-blue-500/50 text-blue-400 font-bold hover:bg-blue-600/30' 
                      : 'bg-slate-800/50 border-slate-700 text-slate-500 hover:border-slate-600'
                  }`}
                >
                  <span className="text-[10px] opacity-50 uppercase mb-0.5">CH</span>
                  <span className="text-sm">{cp.chId}</span>
                  {cp.progress > 0 && (
                    <div className="absolute top-1 right-1">
                      <div className={`text-[8px] font-bold px-1 rounded ${cp.progress >= 80 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-blue-500/20 text-blue-400'}`}>
                        {cp.progress}%
                      </div>
                    </div>
                  )}
                  {cp.progress > 0 && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-800 rounded-b-lg overflow-hidden">
                      <div 
                        className={`h-full transition-all ${cp.progress >= 80 ? 'bg-emerald-500' : 'bg-blue-500'}`} 
                        style={{ width: `${cp.progress}%` }}
                      ></div>
                    </div>
                  )}
                  {cp.count > 0 && cp.progress === 0 && <span className="absolute bottom-1 w-1 h-1 bg-blue-400/40 rounded-full"></span>}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-6">
            <h4 className="text-lg font-semibold mb-4 flex items-center">
              <span className="w-1.5 h-6 bg-emerald-500 rounded-full mr-3"></span>
              Kosakata Terbaru
            </h4>
            <div className="space-y-3">
              {recentVocabs.length === 0 ? (
                <p className="text-zinc-600 text-sm italic py-4">Belum ada kosakata yang ditambahkan.</p>
              ) : (
                recentVocabs.map((v) => (
                  <div key={v.id} className="flex items-center justify-between p-4 bg-zinc-950 border border-zinc-800 rounded-2xl">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-blue-600/10 rounded-xl flex items-center justify-center text-blue-500 font-black">
                        {v.word.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-white">{v.word}</p>
                        <p className="text-xs text-zinc-500">{v.meaning}</p>
                      </div>
                    </div>
                    {v.chapterId && (
                      <span className="text-[9px] font-black bg-blue-600/20 text-blue-500 px-2 py-1 rounded uppercase tracking-widest">
                        Bab {v.chapterId}
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col min-h-[300px]">
          <h4 className="font-bold text-slate-300 mb-6 flex items-center uppercase tracking-widest text-xs">
            <svg className="w-4 h-4 mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 10zM12 14l9-9-9-9-9 9 9 9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            Hubungi CS
          </h4>

          <div className="flex-1 flex flex-col space-y-4">
            <p className="text-xs text-slate-400 leading-relaxed">
              Jika Anda menemukan kesalahan penulisan, bug, atau memiliki pertanyaan seputar aplikasi, silakan hubungi tim dukungan kami melalui saluran di bawah ini:
            </p>
            
            <div className="space-y-3 pt-2">
              <a 
                href="mailto:lancarkoreaa@gmail.com" 
                className="flex items-center p-4 bg-slate-800/50 border border-slate-700 rounded-xl hover:bg-slate-800 transition-all group"
              >
                <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center mr-4 group-hover:bg-blue-500/20 transition-colors">
                  <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none mb-1">Email Support</p>
                  <p className="text-sm font-bold text-white">lancarkoreaa@gmail.com</p>
                </div>
              </a>

              <a 
                href="https://wa.me/6282277294396" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center p-4 bg-slate-800/50 border border-slate-700 rounded-xl hover:bg-slate-800 transition-all group"
              >
                <div className="w-10 h-10 bg-emerald-500/10 rounded-lg flex items-center justify-center mr-4 group-hover:bg-emerald-500/20 transition-colors">
                  <svg className="w-5 h-5 text-emerald-500" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                  </svg>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none mb-1">WhatsApp Support</p>
                  <p className="text-sm font-bold text-white">0822-7729-4396</p>
                </div>
              </a>
            </div>

            <div className="mt-auto p-4 bg-blue-600/5 border border-blue-500/10 rounded-2xl">
              <p className="text-[10px] text-blue-400 font-medium italic">
                "Masukan Anda sangat berharga bagi pengembangan aplikasi ini."
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
