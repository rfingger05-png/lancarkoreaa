
import { useState, useEffect, FC, FormEvent } from 'react';
import { User, Key, Plus, Trash2, CheckCircle2, XCircle, RefreshCcw, ShieldAlert, Mail, Lock } from 'lucide-react';

interface InvitationCode {
  id: string;
  code: string;
  is_used: boolean;
  used_by?: string;
  used_at?: number;
  created_at: number;
}

const Admin: FC = () => {
  const [codes, setCodes] = useState<InvitationCode[]>([]);
  const [newCode, setNewCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Password change state
  const [targetEmail, setTargetEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [pwdLoading, setPwdLoading] = useState(false);
  const [pwdError, setPwdError] = useState('');
  const [pwdSuccess, setPwdSuccess] = useState('');

  const fetchCodes = async () => {
    try {
      setLoading(true);
      setError('');
      const res = await fetch('/api/admin/invitation-codes');
      if (!res.ok) throw new Error('Gagal mengambil data kode.');
      const data = await res.json();
      setCodes(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCodes();
  }, []);

  const handleGenerate = async () => {
    if (!newCode) return;
    try {
      setLoading(true);
      setError('');
      setSuccess('');
      const res = await fetch('/api/admin/invitation-codes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: newCode })
      });
      if (!res.ok) throw new Error('Gagal membuat kode baru.');
      setNewCode('');
      setSuccess('Kode berhasil dibuat!');
      fetchCodes();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Hapus kode ini?')) return;
    try {
      setLoading(true);
      setError('');
      setSuccess('');
      const res = await fetch(`/api/admin/invitation-codes/${id}`, {
        method: 'DELETE'
      });
      if (!res.ok) throw new Error('Gagal menghapus kode.');
      setSuccess('Kode berhasil dihapus!');
      fetchCodes();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChange = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!targetEmail || !newPassword) {
      setPwdError('Email dan Password baru wajib diisi.');
      return;
    }

    if (newPassword.length < 6) {
      setPwdError('Password minimal 6 karakter.');
      return;
    }

    try {
      setPwdLoading(true);
      setPwdError('');
      setPwdSuccess('');
      
      console.log('Memulai proses ganti password untuk:', targetEmail);

      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail.trim().toLowerCase(), newPassword })
      });
      
      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || 'Gagal mengganti password.');
      }
      
      setPwdSuccess(data.message || 'Password berhasil diperbarui!');
      alert('SUKSES: Password berhasil diperbarui!');
      setTargetEmail('');
      setNewPassword('');
    } catch (err: any) {
      console.error('Password change error:', err);
      setPwdError(err.message);
      alert('ERROR: ' + err.message);
    } finally {
      setPwdLoading(false);
    }
  };

  const generateRandomCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = 'LK-';
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewCode(result);
  };

  const handleBatchGenerate = async () => {
    if (!confirm('Generate 10 kode baru sekaligus?')) return;
    try {
      setLoading(true);
      setError('');
      setSuccess('');
      const res = await fetch('/api/admin/invitation-codes/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ count: 10 })
      });
      if (!res.ok) throw new Error('Gagal membuat kode batch.');
      setSuccess('10 kode baru berhasil dibuat!');
      fetchCodes();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase italic">Admin <span className="text-blue-500">Panel</span></h2>
          <p className="text-zinc-500 font-bold text-xs uppercase tracking-widest mt-1">Manage Invitation Codes</p>
        </div>
        <button 
          onClick={fetchCodes}
          className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-white transition-all active:scale-95"
          disabled={loading}
        >
          <RefreshCcw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 flex items-center gap-3 text-red-500 text-sm font-bold">
          <XCircle className="w-5 h-5" />
          {error}
        </div>
      )}

      {success && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4 flex items-center gap-3 text-emerald-500 text-sm font-bold">
          <CheckCircle2 className="w-5 h-5" />
          {success}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Generate Section */}
        <div className="md:col-span-1 space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-[2rem] p-6 shadow-xl">
            <h3 className="text-sm font-black text-zinc-400 uppercase tracking-widest mb-6 flex items-center gap-2">
              <Plus className="w-4 h-4 text-blue-500" /> Buat Kode Baru
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 ml-1">Kode Undangan</label>
                <input 
                  type="text" 
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value.toUpperCase())}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-blue-500 transition-all"
                  placeholder="CONTOH-KODE-123"
                />
              </div>
              <button 
                onClick={generateRandomCode}
                className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all"
              >
                Generate Random
              </button>
              <button 
                onClick={handleBatchGenerate}
                disabled={loading}
                className="w-full bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-500 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all border border-emerald-500/20"
              >
                Batch Generate (10)
              </button>
              <button 
                onClick={handleGenerate}
                disabled={!newCode || loading}
                className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white py-4 rounded-xl font-black uppercase tracking-widest transition-all shadow-lg shadow-blue-900/20"
              >
                Simpan Kode
              </button>
            </div>
          </div>
        </div>

        {/* Password Reset Section */}
        <div className="md:col-span-3">
          <div className="bg-zinc-900 border border-zinc-800 rounded-[2rem] p-8 shadow-xl relative overflow-hidden">
            <div className="absolute -top-12 -right-12 w-32 h-32 bg-red-500/5 rounded-full blur-3xl pointer-events-none"></div>
            
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Ganti Password User</h3>
                <p className="text-zinc-500 font-bold text-[10px] uppercase tracking-widest">Admin Override Feature</p>
              </div>
            </div>

            <form onSubmit={handlePasswordChange} className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Email User</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                  <input 
                    type="email" 
                    value={targetEmail}
                    onChange={(e) => setTargetEmail(e.target.value)}
                    placeholder="user@example.com"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-12 pr-4 py-4 text-white font-bold outline-none focus:border-red-500 transition-all"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Password Baru</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                  <input 
                    type="password" 
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-12 pr-4 py-4 text-white font-bold outline-none focus:border-red-500 transition-all"
                    required
                    minLength={6}
                  />
                </div>
              </div>
              <button 
                type="submit"
                disabled={pwdLoading}
                className="bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white py-4 px-8 rounded-xl font-black uppercase tracking-widest transition-all shadow-lg shadow-red-900/20 active:scale-95"
              >
                {pwdLoading ? 'Memproses...' : 'Update Password'}
              </button>
            </form>

            {pwdError && (
              <div className="mt-6 bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-3 text-red-500 text-xs font-bold">
                <XCircle className="w-4 h-4" />
                {pwdError}
              </div>
            )}

            {pwdSuccess && (
              <div className="mt-6 bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 flex items-center gap-3 text-emerald-500 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4" />
                {pwdSuccess}
              </div>
            )}
          </div>
        </div>

        {/* List Section */}
        <div className="md:col-span-2 space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-[2rem] p-6 shadow-xl min-h-[400px]">
            <h3 className="text-sm font-black text-zinc-400 uppercase tracking-widest mb-6 flex items-center gap-2">
              <Key className="w-4 h-4 text-blue-500" /> Daftar Kode
            </h3>
            
            <div className="space-y-3">
              {codes.length === 0 && !loading && (
                <div className="py-20 text-center text-zinc-600">
                  <Key className="w-12 h-12 mx-auto mb-4 opacity-10" />
                  <p className="font-bold text-sm">Belum ada kode undangan.</p>
                </div>
              )}
              
              {codes.map((c) => (
                <div key={c.id} className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 flex items-center justify-between group hover:border-zinc-700 transition-all">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${c.is_used ? 'bg-zinc-900 text-zinc-600' : 'bg-blue-600/10 text-blue-500'}`}>
                      <Key className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className={`font-black tracking-tight ${c.is_used ? 'text-zinc-600 line-through' : 'text-white'}`}>{c.code}</h4>
                      <div className="flex items-center gap-2 mt-0.5">
                        {c.is_used ? (
                          <span className="flex items-center gap-1 text-[9px] font-black text-zinc-600 uppercase tracking-tighter">
                            <CheckCircle2 className="w-2.5 h-2.5" /> Terpakai oleh {c.used_by?.substring(0, 8)}...
                          </span>
                        ) : (
                          <span className="text-[9px] font-black text-emerald-500 uppercase tracking-tighter">Tersedia</span>
                        )}
                      </div>
                    </div>
                  </div>
                  {!c.is_used && (
                    <button 
                      onClick={() => handleDelete(c.id)}
                      className="p-2 text-zinc-700 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;
