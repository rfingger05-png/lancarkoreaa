
import { useState, FC, useMemo } from 'react';
import { Vocab, Grammar, PracticeSession, User } from '../types';
import { db } from '../services/db';
import { 
  CheckCircle2, 
  ArrowLeft, 
  Trophy, 
  BookOpen, 
  Image as ImageIcon, 
  Languages, 
  RotateCcw, 
  HelpCircle,
  Check,
  X,
  MessageSquare,
  ChevronRight,
  Layers,
  Hash,
  Play,
  Plus,
  AlignLeft,
  StickyNote
} from 'lucide-react';

interface PracticeProps {
  vocabs: Vocab[];
  grammars: Grammar[];
  onRefresh: () => void;
  user: User;
}

const Practice: FC<PracticeProps> = ({ vocabs, grammars, onRefresh, user }) => {
  const [session, setSession] = useState<PracticeSession | null>(null);
  const [quizList, setQuizList] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [selectedChapters, setSelectedChapters] = useState<number[]>([]);
  const [modeFilter, setModeFilter] = useState<'all' | 'chapter' | 'additional' | 'grammar' | 'unit'>('all');
  const [unitSubFilter, setUnitSubFilter] = useState<'all' | 'native' | 'sino'>('all');
  const [numQuestions, setNumQuestions] = useState<number>(10);
  const [showGrammarDetail, setShowGrammarDetail] = useState(false);

  const getBaseFilteredVocabs = () => {
    let filtered = vocabs;
    if (modeFilter === 'chapter') {
      if (selectedChapters.length > 0) {
        filtered = filtered.filter(v => v.chapterId && selectedChapters.includes(v.chapterId));
      } else {
        filtered = filtered.filter(v => !!v.chapterId);
      }
    } else if (modeFilter === 'additional') {
      filtered = filtered.filter(v => !v.chapterId && !v.isUnit);
    } else if (modeFilter === 'unit') {
      filtered = filtered.filter(v => !v.chapterId && v.isUnit);
      if (unitSubFilter !== 'all') {
        filtered = filtered.filter(v => v.unitType === unitSubFilter);
      }
    }
    return filtered;
  };

  const getUniqueItems = (items: any[], type: string) => {
    const uniqueMap = new Map();
    items.forEach(item => {
      let key;
      if (type === 'grammar') key = item.title;
      else if (type === 'reverse') key = item.meaning;
      else if (type === 'image') key = item.imageUrl;
      else key = item.word; // meaning, unit, etc.

      if (!uniqueMap.has(key)) {
        uniqueMap.set(key, item);
      }
    });
    return Array.from(uniqueMap.values());
  };

  const startPractice = (type: PracticeSession['type']) => {
    let filtered: any[] = [];
    
    if (type === 'grammar') {
      filtered = grammars;
      if (filtered.length === 0) {
        alert('Belum ada materi grammar untuk latihan!');
        return;
      }
    } else {
      filtered = getBaseFilteredVocabs();

      // FORCE UNIT FILTER if type is 'unit'
      if (type === 'unit') {
        filtered = filtered.filter(v => v.isUnit);
        if (filtered.length === 0) {
          alert('Tidak ada data satuan benda untuk dilatih!');
          return;
        }
      }

      // PERBAIKAN BUG: Pemisahan total antara tipe gambar dan tipe biasa
      if (type === 'image') {
        filtered = filtered.filter(v => !!v.imageUrl);
        if (filtered.length === 0) {
          alert('Tidak ada kosakata bergambar dalam kategori ini!');
          return;
        }
      } else {
        // Untuk 'meaning' dan 'reverse', buang semua yang punya gambar
        filtered = filtered.filter(v => !v.imageUrl);
        if (filtered.length === 0) {
          alert('Tidak ada kosakata biasa (non-gambar) dalam kategori ini!');
          return;
        }
      }
    }

    // PERBAIKAN: Hapus duplikasi soal (jika ada kata yang sama di bab berbeda)
    filtered = getUniqueItems(filtered, type);

    if (numQuestions <= 0) {
      alert('Masukkan jumlah soal yang valid!');
      return;
    }

    const finalCount = Math.min(numQuestions, filtered.length);
    const shuffled = [...filtered].sort(() => Math.random() - 0.5).slice(0, finalCount);
    
    setQuizList(shuffled);
    setSession({ 
      type, 
      chapterIds: modeFilter === 'chapter' ? [...selectedChapters] : [], 
      includeAdditional: modeFilter !== 'chapter',
      unitFilter: modeFilter === 'unit' ? unitSubFilter : undefined
    });
    setCurrentIndex(0);
    setShowAnswer(false);
    setScore(0);
    setIsFinished(false);
  };

  const finishLatihan = async (finalScore: number) => {
    if (session) {
      await db.addHistory({
        userId: user.id,
        type: session.type,
        chapterIds: session.chapterIds,
        includeAdditional: session.includeAdditional,
        score: finalScore,
        total: quizList.length
      });
      onRefresh();
    }
    setIsFinished(true);
  };

  const handleNext = (correct: boolean) => {
    const newScore = correct ? score + 1 : score;
    if (correct) setScore(newScore);
    
    if (currentIndex + 1 < quizList.length) {
      setCurrentIndex(currentIndex + 1);
      setShowAnswer(false);
      setShowGrammarDetail(false);
    } else {
      finishLatihan(newScore);
    }
  };

  const toggleChapter = (id: number) => {
    setSelectedChapters(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  // Hitung jumlah unik untuk UI dengan useMemo agar tidak lag saat gonta-ganti menu
  const { imageCount, textOnlyCount, uniqueGrammarCount } = useMemo(() => {
    const baseFiltered = getBaseFilteredVocabs();
    const uniqueBaseFiltered = getUniqueItems(baseFiltered, 'vocab');
    return {
      imageCount: uniqueBaseFiltered.filter(v => !!v.imageUrl).length,
      textOnlyCount: uniqueBaseFiltered.filter(v => !v.imageUrl).length,
      uniqueGrammarCount: getUniqueItems(grammars, 'grammar').length
    };
  }, [vocabs, grammars, modeFilter, selectedChapters, unitSubFilter]);

  if (isFinished) {
    return (
      <div className="flex flex-col items-center justify-center h-full py-12 text-center">
        <div className="relative mb-8">
          <div className="w-24 h-24 bg-blue-600 rounded-[2rem] flex items-center justify-center shadow-2xl shadow-blue-900/50 rotate-12">
            <Trophy className="w-12 h-12 text-white -rotate-12" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg border-4 border-slate-950">
            <CheckCircle2 className="w-5 h-5 text-white" />
          </div>
        </div>
        
        <h2 className="text-4xl font-black mb-2 text-white tracking-tighter">Latihan Selesai!</h2>
        <p className="text-slate-500 mb-8 max-w-xs mx-auto font-medium text-sm">Luar biasa! Data latihan Anda telah berhasil disimpan ke riwayat belajar.</p>
        
        <div className="bg-slate-900 border border-slate-800 rounded-[1.5rem] p-6 mb-8 w-full max-w-xs shadow-2xl">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">Skor Akhir</p>
          <div className="text-6xl font-black text-blue-500 tracking-tighter">
            {score}<span className="text-slate-700 text-3xl">/{quizList.length}</span>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-800 flex justify-between items-center">
            <div className="text-left">
              <p className="text-[10px] font-bold text-slate-500 uppercase">Akurasi</p>
              <p className="text-base font-black text-white">{Math.round((score / quizList.length) * 100)}%</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-bold text-slate-500 uppercase">Tipe</p>
              <p className="text-base font-black text-blue-400 capitalize">{session?.type}</p>
            </div>
          </div>
        </div>

        <button 
          onClick={() => setSession(null)}
          className="group bg-blue-600 hover:bg-blue-500 text-white px-8 py-4 rounded-xl font-black transition-all shadow-xl shadow-blue-900/20 flex items-center gap-2 text-base active:scale-95"
        >
          <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          Kembali ke Menu
        </button>
      </div>
    );
  }

  if (session && quizList.length > 0) {
    const current = quizList[currentIndex];
    return (
      <>
        <div className="max-w-xl mx-auto space-y-6 pb-20">
          <div className="flex items-center justify-between px-2">
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Progress</span>
              <div className="flex items-center gap-2">
                <div className="w-24 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-blue-500 h-full transition-all duration-500" style={{ width: `${((currentIndex + 1) / quizList.length) * 100}%` }}></div>
                </div>
                <span className="text-xs font-black text-white">{currentIndex + 1} <span className="text-slate-500">/ {quizList.length}</span></span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1 block">Skor</span>
              <div className="flex items-center gap-1.5 justify-end">
                <div className="w-5 h-5 bg-emerald-500/20 rounded-md flex items-center justify-center">
                  <Check className="w-3 h-3 text-emerald-500" />
                </div>
                <span className="text-lg font-black text-emerald-500">{score}</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-[2rem] p-8 shadow-2xl text-center min-h-[380px] flex flex-col justify-center relative overflow-hidden group">
            {/* Background Decorative Element */}
            <div className="absolute -top-10 -right-10 w-48 h-48 bg-blue-600/5 rounded-full blur-3xl group-hover:bg-blue-600/10 transition-colors pointer-events-none"></div>
            
            {session.type === 'grammar' ? (
              <div className="space-y-4 relative z-20">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-600/10 border border-blue-500/20 rounded-xl text-blue-400 text-[9px] font-black uppercase tracking-[0.2em] mb-2">
                  <Languages className="w-2.5 h-2.5" /> Grammar
                </div>
                <button 
                  type="button"
                  onClick={() => setShowGrammarDetail(true)}
                  className="block w-full group/title cursor-pointer relative z-30 py-2"
                >
                  <h3 className="text-4xl font-black text-white tracking-tighter leading-tight mb-2 group-hover/title:text-blue-400 transition-colors">{current.title}</h3>
                  <div className="flex items-center justify-center gap-1.5 text-slate-600 text-[10px] font-bold uppercase tracking-widest group-hover/title:text-slate-400 transition-colors">
                    <HelpCircle className="w-3 h-3" /> Klik untuk penjelasan
                  </div>
                </button>
                <div className="w-12 h-1 bg-blue-600/30 mx-auto rounded-full mb-6"></div>
                <p className="text-slate-500 font-medium text-base italic">"Apa arti tatabahasa ini?"</p>
              </div>
            ) : session.type === 'image' && current.imageUrl ? (
            <div className="mb-6 relative z-10">
              <div className="relative inline-block">
                <img src={current.imageUrl} alt="Quiz" className="max-h-48 mx-auto rounded-2xl object-contain shadow-2xl bg-slate-950 p-3 border border-slate-800" />
                <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-xl border-4 border-slate-900">
                  <ImageIcon className="w-5 h-5 text-white" />
                </div>
              </div>
              <p className="text-[9px] text-emerald-500 font-black uppercase tracking-[0.2em] mt-8">Tebak Kata Korea</p>
            </div>
          ) : session.type === 'reverse' ? (
            <div className="space-y-4 relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-purple-600/10 border border-purple-500/20 rounded-xl text-purple-400 text-[9px] font-black uppercase tracking-[0.2em] mb-2">
                <RotateCcw className="w-2.5 h-2.5" /> Terbalik
              </div>
              <h3 className="text-4xl font-black text-white tracking-tight leading-tight mb-6">{current.meaning}</h3>
              <p className="text-slate-500 font-medium text-base italic">"Tuliskan kata Koreanya"</p>
            </div>
          ) : (
            <div className="space-y-4 relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-slate-400 text-[9px] font-black uppercase tracking-[0.2em] mb-2">
                <HelpCircle className="w-2.5 h-2.5" /> {session.type === 'unit' ? 'Satuan Benda' : 'Tebak Arti'}
              </div>
              <h3 className="text-5xl font-black text-white tracking-tighter leading-tight mb-6">{current.word}</h3>
              <p className="text-slate-500 font-medium text-base italic">
                {session.type === 'unit' ? `Sistem: ${current.unitType === 'native' ? 'Asli Korea' : 'Sino Korea'}` : '"Apa arti kata ini?"'}
              </p>
            </div>
          )}

          {showAnswer ? (
            <div className="relative z-10 mt-8">
              <div className={`text-3xl font-black text-white mb-6 p-6 rounded-2xl border shadow-xl ${session.type === 'image' ? 'bg-emerald-600/5 border-emerald-500/20' : 'bg-blue-600/5 border-blue-500/20'}`}>
                {(session.type === 'meaning' || session.type === 'unit' || session.type === 'grammar') ? current.meaning : current.word}
              </div>
              
              {session.type === 'image' && (
                <div className="flex items-center justify-center gap-2 text-slate-400 mb-6 font-bold text-base">
                  <Languages className="w-4 h-4" /> Arti: {current.meaning}
                </div>
              )}
              
              {session.type === 'grammar' && current.exampleSentence && (
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 mb-6 text-left relative overflow-hidden group/example">
                  <p className="text-[9px] text-blue-500 font-black uppercase tracking-widest mb-2 flex items-center gap-1.5">
                    <MessageSquare className="w-2.5 h-2.5" /> Contoh
                  </p>
                  <p className="text-lg text-white font-black italic mb-1 leading-tight">"{current.exampleSentence}"</p>
                  <p className="text-xs text-slate-500 font-medium">{current.exampleExplanation}</p>
                </div>
              )}

              <div className="flex gap-3">
                <button 
                  onClick={() => handleNext(false)} 
                  className="flex-1 bg-slate-950 hover:bg-red-600/10 text-slate-500 hover:text-red-500 border border-slate-800 hover:border-red-500/50 py-4 rounded-xl font-black transition-all flex items-center justify-center gap-2 active:scale-95 text-sm"
                >
                  <X className="w-5 h-5" /> Salah
                </button>
                <button 
                  onClick={() => handleNext(true)} 
                  className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-xl font-black transition-all shadow-xl shadow-blue-900/20 flex items-center justify-center gap-2 active:scale-95 text-sm"
                >
                  <Check className="w-5 h-5" /> Benar
                </button>
              </div>
            </div>
          ) : (
            <button 
              onClick={() => setShowAnswer(true)}
              className={`w-full py-5 rounded-xl font-black text-lg transition-all shadow-xl border relative z-10 group/btn active:scale-95 ${
                session.type === 'image' 
                  ? 'bg-emerald-600 hover:bg-emerald-500 border-emerald-500 text-white shadow-emerald-900/20' 
                  : 'bg-blue-600 hover:bg-blue-500 border-blue-500 text-white shadow-blue-900/20'
              }`}
            >
              Lihat Jawaban
            </button>
          )}
        </div>

        </div>

        {/* Grammar Detail Modal */}
        {showGrammarDetail && session.type === 'grammar' && (
          <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 sm:p-6">
            <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => setShowGrammarDetail(false)}></div>
            <div className="bg-slate-900 border border-slate-800 w-full max-w-4xl max-h-[85vh] rounded-[2.5rem] shadow-2xl relative z-[10000] overflow-hidden flex flex-col">
              <div className="p-8 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
                <div>
                  <span className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em] mb-1 block">Detail Tatabahasa</span>
                  <h4 className="text-3xl font-black text-white tracking-tighter">{current.title}</h4>
                </div>
                <button 
                  onClick={() => setShowGrammarDetail(false)}
                  className="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center justify-center text-slate-400 hover:text-white transition-all"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="p-8 overflow-y-auto custom-scrollbar space-y-8">
                <div>
                  <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                    <Languages className="w-3 h-3" /> Arti & Makna
                  </h5>
                  <p className="text-2xl text-white font-bold">{current.meaning}</p>
                </div>

                {current.description && (
                  <div>
                    <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                      <AlignLeft className="w-3 h-3" /> Penjelasan
                    </h5>
                    <div className="bg-slate-950/50 border border-slate-800 rounded-2xl p-5">
                      <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">{current.description}</p>
                    </div>
                  </div>
                )}

                {current.exampleSentence && (
                  <div>
                    <h5 className="text-[10px] font-black text-emerald-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                      <MessageSquare className="w-3 h-3" /> Contoh Kalimat
                    </h5>
                    <div className="bg-emerald-600/5 border border-emerald-500/20 rounded-2xl p-5">
                      <p className="text-xl text-white font-black italic mb-1">"{current.exampleSentence}"</p>
                      <p className="text-sm text-emerald-400/80 font-medium">{current.exampleExplanation}</p>
                    </div>
                  </div>
                )}

                {current.notes && (
                  <div>
                    <h5 className="text-[10px] font-black text-amber-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                      <StickyNote className="w-3 h-3" /> Tips & Catatan
                    </h5>
                    <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-5">
                      <p className="text-slate-400 text-sm italic leading-relaxed">{current.notes}</p>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="p-6 bg-slate-950/50 border-t border-slate-800">
                <button 
                  onClick={() => setShowGrammarDetail(false)}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-4 rounded-xl transition-all"
                >
                  Tutup Penjelasan
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      <div className="text-center space-y-2">
        <h2 className="text-4xl font-black text-white tracking-tighter">Mode Latihan</h2>
        <p className="text-slate-500 font-medium max-w-md mx-auto text-sm">Tingkatkan kemampuan bahasa Korea Anda dengan mode interaktif.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-[1.5rem] p-6 shadow-xl">
            <h4 className="font-black text-[10px] uppercase tracking-[0.2em] text-blue-500 mb-4 flex items-center gap-2">
              <Layers className="w-3.5 h-3.5" /> 1. Pilih Materi
            </h4>
            <div className="space-y-2">
              {[
                { id: 'all', label: 'Semua Materi', icon: BookOpen },
                { id: 'additional', label: 'Kosakata Tambahan', icon: Plus },
                { id: 'unit', label: 'Satuan Benda', icon: Hash },
                { id: 'chapter', label: 'Pilih Bab Spesifik', icon: Hash },
                { id: 'grammar', label: 'Materi Grammar', icon: Languages }
              ].map(mode => (
                <button 
                  key={mode.id}
                  onClick={() => setModeFilter(mode.id as any)} 
                  className={`w-full p-3 rounded-xl border text-left transition-all flex items-center justify-between group ${modeFilter === mode.id ? 'bg-blue-600/10 border-blue-500 text-blue-400 shadow-inner' : 'bg-slate-950 border-slate-800 text-slate-500 hover:border-slate-600 hover:bg-slate-900'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${modeFilter === mode.id ? 'bg-blue-600 text-white' : 'bg-slate-900 text-slate-600 group-hover:text-slate-400'}`}>
                      <mode.icon className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-xs">{mode.label}</span>
                  </div>
                  {modeFilter === mode.id && <CheckCircle2 className="w-4 h-4" />}
                </button>
              ))}
            </div>

            {modeFilter === 'unit' && (
              <div className="mt-4 pt-4 border-t border-slate-800">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Sistem Bilangan</p>
                <div className="flex gap-2">
                  {(['all', 'native', 'sino'] as const).map(type => (
                    <button 
                      key={type}
                      onClick={() => setUnitSubFilter(type)}
                      className={`flex-1 py-2 rounded-lg text-[10px] font-black transition-all border ${unitSubFilter === type ? 'bg-emerald-600 border-emerald-500 text-white shadow-lg shadow-emerald-900/20' : 'bg-slate-950 border-slate-800 text-slate-600 hover:border-slate-600 hover:text-slate-300'}`}
                    >
                      {type === 'all' ? 'SEMUA' : type === 'native' ? 'ASLI' : 'SINO'}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {modeFilter === 'chapter' && (
              <div className="mt-4 pt-4 border-t border-slate-800">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Daftar Bab (1-60)</p>
                <div className="grid grid-cols-6 gap-1.5 max-h-32 overflow-y-auto pr-2 custom-scrollbar">
                  {Array.from({ length: 60 }, (_, i) => i + 1).map(id => (
                    <button 
                      key={id} 
                      onClick={() => toggleChapter(id)} 
                      className={`h-8 rounded-lg text-[10px] font-black transition-all border ${selectedChapters.includes(id) ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/20' : 'bg-slate-950 border-slate-800 text-slate-600 hover:border-slate-600 hover:text-slate-300'}`}
                    >
                      {id}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-[1.5rem] p-6 shadow-xl">
            <h4 className="font-black text-[10px] uppercase tracking-[0.2em] text-blue-500 mb-4 flex items-center gap-2">
              <Hash className="w-3.5 h-3.5" /> 2. Jumlah Soal
            </h4>
            <div className="relative group">
              <input 
                type="number" 
                value={numQuestions} 
                onChange={(e) => setNumQuestions(parseInt(e.target.value) || 0)}
                className="w-full bg-slate-950 border-2 border-slate-800 rounded-xl px-4 py-3 text-xl font-black outline-none transition-all text-white focus:border-blue-500 group-hover:border-slate-700"
              />
              <div className="mt-3 flex flex-wrap gap-1.5">
                {[5, 10, 20, 50].map(v => (
                  <button 
                    key={v} 
                    onClick={() => setNumQuestions(v)} 
                    className={`px-3 py-1.5 rounded-lg text-[10px] font-black transition-all border ${numQuestions === v ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/20' : 'bg-slate-950 border-slate-800 text-slate-600 hover:border-slate-600 hover:text-slate-300'}`}
                  >
                    {v}
                  </button>
                ))}
              </div>
              <div className="mt-4 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  {modeFilter === 'grammar' ? (
                    <div className="col-span-2 bg-slate-950 border border-slate-800 rounded-lg p-2 flex items-center justify-between">
                      <span className="text-[9px] font-bold text-slate-500">Grammar</span>
                      <span className="text-[10px] font-black text-blue-400">{uniqueGrammarCount}</span>
                    </div>
                  ) : (
                    <>
                      <div className="bg-slate-950 border border-slate-800 rounded-lg p-2 flex items-center justify-between">
                        <span className="text-[9px] font-bold text-slate-500">Biasa</span>
                        <span className="text-[10px] font-black text-blue-400">{textOnlyCount}</span>
                      </div>
                      <div className="bg-slate-950 border border-slate-800 rounded-lg p-2 flex items-center justify-between">
                        <span className="text-[9px] font-bold text-slate-500">Gambar</span>
                        <span className="text-[10px] font-black text-emerald-400">{imageCount}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="font-black text-[10px] uppercase tracking-[0.2em] text-slate-500 px-2">3. Pilih Mode Latihan</h4>
          
          <div className="grid grid-cols-1 gap-3">
            <div className="space-y-2">
              <p className="text-[9px] font-black text-blue-500 uppercase tracking-[0.2em] px-2">Kosakata Dasar</p>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => startPractice('meaning')} 
                  className="group relative bg-slate-900 border border-slate-800 rounded-[1.5rem] p-5 hover:border-blue-500 transition-all text-left overflow-hidden active:scale-95"
                >
                  <div className="w-10 h-10 bg-blue-600/10 text-blue-500 rounded-xl flex items-center justify-center mb-4 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-lg">
                    <Languages className="w-5 h-5" />
                  </div>
                  <h5 className="font-black text-sm text-white mb-0.5">Tebak Arti</h5>
                  <p className="text-[10px] text-slate-500 font-medium">Korea <ChevronRight className="inline w-2.5 h-2.5" /> Indo</p>
                </button>
                
                <button 
                  onClick={() => startPractice('reverse')} 
                  className="group relative bg-slate-900 border border-slate-800 rounded-[1.5rem] p-5 hover:border-purple-500 transition-all text-left overflow-hidden active:scale-95"
                >
                  <div className="w-10 h-10 bg-purple-600/10 text-purple-500 rounded-xl flex items-center justify-center mb-4 group-hover:bg-purple-600 group-hover:text-white transition-all shadow-lg">
                    <RotateCcw className="w-5 h-5" />
                  </div>
                  <h5 className="font-black text-sm text-white mb-0.5">Terbalik</h5>
                  <p className="text-[10px] text-slate-500 font-medium">Indo <ChevronRight className="inline w-2.5 h-2.5" /> Korea</p>
                </button>
              </div>
            </div>
            
            <div className="space-y-2 pt-2">
              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-[0.2em] px-2">Kosakata Visual</p>
              <button 
                onClick={() => startPractice('image')} 
                disabled={imageCount === 0 || modeFilter === 'grammar'} 
                className={`group relative w-full flex items-center p-5 bg-slate-900 border rounded-[1.5rem] transition-all text-left overflow-hidden active:scale-[0.98] ${imageCount > 0 && modeFilter !== 'grammar' ? 'border-slate-800 hover:border-emerald-500 cursor-pointer' : 'border-slate-800/40 opacity-40 cursor-not-allowed'}`}
              >
                <div className="w-12 h-12 bg-emerald-600/10 text-emerald-500 rounded-xl flex items-center justify-center mr-4 group-hover:bg-emerald-600 group-hover:text-white transition-all shadow-lg">
                  <ImageIcon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h5 className="font-black text-base text-white mb-0.5">Tebak Gambar</h5>
                  <p className="text-[10px] text-slate-500 font-medium italic">Visual <ChevronRight className="inline w-2.5 h-2.5" /> Korea</p>
                </div>
                {imageCount > 0 && (
                  <div className="bg-emerald-500 text-white text-[9px] font-black px-3 py-1 rounded-lg shadow-xl shadow-emerald-900/20">
                    {imageCount} Item
                  </div>
                )}
              </button>
            </div>

            <div className="space-y-2 pt-2">
              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-[0.2em] px-2">Satuan Benda</p>
              <button 
                onClick={() => startPractice('unit')} 
                disabled={modeFilter === 'grammar' || (modeFilter === 'unit' && textOnlyCount === 0)} 
                className={`group relative w-full flex items-center p-5 bg-slate-900 border rounded-[1.5rem] transition-all text-left overflow-hidden active:scale-[0.98] ${modeFilter !== 'grammar' && (modeFilter !== 'unit' || textOnlyCount > 0) ? 'border-slate-800 hover:border-emerald-500 cursor-pointer' : 'border-slate-800/40 opacity-40 cursor-not-allowed'}`}
              >
                <div className="w-12 h-12 bg-emerald-600/10 text-emerald-500 rounded-xl flex items-center justify-center mr-4 group-hover:bg-emerald-600 group-hover:text-white transition-all shadow-lg">
                  <Hash className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h5 className="font-black text-base text-white mb-0.5">Latihan Satuan</h5>
                  <p className="text-[10px] text-slate-500 font-medium italic">Unit Benda <ChevronRight className="inline w-2.5 h-2.5" /> Indo</p>
                </div>
                {modeFilter === 'unit' && (
                  <div className="bg-emerald-500 text-white text-[9px] font-black px-3 py-1 rounded-lg shadow-xl shadow-emerald-900/20">
                    {textOnlyCount} Item
                  </div>
                )}
              </button>
            </div>

            {modeFilter === 'grammar' && (
              <div className="space-y-2 pt-2">
                <p className="text-[9px] font-black text-blue-500 uppercase tracking-[0.2em] px-2">Tatabahasa</p>
                <button 
                  onClick={() => startPractice('grammar')} 
                  className="group relative w-full flex items-center p-5 bg-slate-900 border border-slate-800 rounded-[1.5rem] hover:border-blue-500 transition-all text-left overflow-hidden active:scale-[0.98]"
                >
                  <div className="w-12 h-12 bg-blue-600/10 text-blue-500 rounded-xl flex items-center justify-center mr-4 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-lg">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h5 className="font-black text-base text-white mb-0.5">Latihan Grammar</h5>
                    <p className="text-[10px] text-slate-500 font-medium italic">Tebak Arti Tatabahasa</p>
                  </div>
                  <div className="bg-blue-600 text-white text-[9px] font-black px-3 py-1.5 rounded-lg shadow-xl shadow-blue-900/20 flex items-center gap-1.5">
                    <Play className="w-2.5 h-2.5 fill-current" /> Mulai
                  </div>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Practice;
