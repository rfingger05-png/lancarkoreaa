
import { Vocab, Grammar, AppState, PracticeHistory } from '../types';
import { get, set } from 'idb-keyval';

const CACHE_KEY = 'lancar_korea_app_state';

const request = async (url: string, options: RequestInit = {}) => {
  const res = await fetch(url, options);
  if (res.status === 401) {
    localStorage.removeItem('lancar_korea_user');
    window.location.reload();
    throw new Error('Sesi habis. Silakan login kembali.');
  }
  if (res.status === 403) {
    throw new Error('Akses Ditolak: Hanya Admin yang bisa melakukan tindakan ini.');
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `Request failed (Status: ${res.status})`);
  }
  return res;
};

export const db = {
  getCache: async (): Promise<AppState | null> => {
    try {
      return await get(CACHE_KEY);
    } catch (e) {
      return null;
    }
  },
  setCache: async (state: AppState) => {
    try {
      await set(CACHE_KEY, state);
    } catch (e) {
      console.warn("Failed to save cache:", e);
    }
  },
  get: async (): Promise<AppState> => {
    try {
      const res = await request('/api/state');
      const state = await res.json();
      db.setCache(state);
      return state;
    } catch (error) {
      console.error("Database fetch error:", error);
      throw error;
    }
  },
  addVocab: async (vocab: Omit<Vocab, 'id' | 'createdAt'>) => {
    const res = await request('/api/vocabs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(vocab)
    });
    return await res.json();
  },
  updateVocab: async (id: string, updates: Partial<Vocab>) => {
    await request(`/api/vocabs/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
  },
  deleteVocab: async (id: string) => {
    await request(`/api/vocabs/${id}`, {
      method: 'DELETE'
    });
  },
  addVocabsBulk: async (vocabs: Omit<Vocab, 'id' | 'createdAt'>[]) => {
    await request('/api/vocabs/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(vocabs)
    });
  },
  deleteVocabsByFilter: async (filter: string) => {
    await request(`/api/vocabs?filter=${filter}`, {
      method: 'DELETE'
    });
  },
  deleteGrammarsByFilter: async (filter: string) => {
    await request(`/api/grammars?filter=${filter}`, {
      method: 'DELETE'
    });
  },
  addGrammar: async (grammar: Omit<Grammar, 'id' | 'createdAt'>) => {
    const res = await request('/api/grammars', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(grammar)
    });
    return await res.json();
  },
  updateGrammar: async (id: string, updates: Partial<Grammar>) => {
    await request(`/api/grammars/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
  },
  deleteGrammar: async (id: string) => {
    await request(`/api/grammars/${id}`, {
      method: 'DELETE'
    });
  },
  addHistory: async (entry: Omit<PracticeHistory, 'id' | 'timestamp'>) => {
    const res = await request('/api/history', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(entry)
    });
    return await res.json();
  }
};
