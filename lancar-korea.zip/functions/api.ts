import serverless from 'serverless-http';
import { app } from '../server.ts';

// serverless-http options
export const handler = serverless(app, {
  binary: ['image/*', 'font/*', 'application/pdf']
});
