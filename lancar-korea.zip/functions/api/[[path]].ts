import { Hono } from 'hono';
import { handle } from 'hono/cloudflare-pages';
import { createClient } from '@supabase/supabase-js';
import { jwt, sign, verify } from 'hono/jwt';
import { getCookie, setCookie } from 'hono/cookie';

type Bindings = {
  VITE_SUPABASE_URL: string;
  SUPABASE_URL: string;
  VITE_SUPABASE_ANON_KEY: string;
  SUPABASE_ANON_KEY: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
  JWT_SECRET: string;
}

type Variables = {
  user: any;
}

const app = new Hono<{ Bindings: Bindings, Variables: Variables }>().basePath('/api');

// --- Helpers ---
const getSupabase = (c: any) => {
  const supabaseUrl = c.env.VITE_SUPABASE_URL || c.env.SUPABASE_URL;
  const supabaseKey = c.env.VITE_SUPABASE_ANON_KEY || c.env.SUPABASE_ANON_KEY;
  return createClient(supabaseUrl, supabaseKey);
};

const getSupabaseAdmin = (c: any) => {
  const supabaseUrl = c.env.VITE_SUPABASE_URL || c.env.SUPABASE_URL;
  const supabaseServiceKey = c.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !supabaseServiceKey) return null;
  return createClient(supabaseUrl, supabaseServiceKey, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
};

const getJWTSecret = (c: any) => c.env.JWT_SECRET || 'lancar-korea-secret-key-123';

// --- Middlewares ---

const authMiddleware = async (c: any, next: any) => {
  const token = getCookie(c, 'token') || c.req.header('Authorization')?.split(' ')[1];
  if (!token) return c.json({ error: 'Akses ditolak. Silakan login.' }, 401);

  try {
    const payload = await verify(token, getJWTSecret(c), 'HS256');
    c.set('user', payload);
    await next();
  } catch (err) {
    return c.json({ error: 'Sesi habis. Silakan login kembali.' }, 401);
  }
};

const adminMiddleware = async (c: any, next: any) => {
  const user = c.get('user');
  if (user?.role !== 'admin') {
    return c.json({ error: 'Akses Ditolak: Hanya Admin yang bisa melakukan tindakan ini.' }, 403);
  }
  await next();
};

// --- Routes ---

app.get('/health', (c) => c.json({ status: 'ok', env: 'cloudflare' }));
app.get('/debug', (c) => c.json({ ok: true, message: 'Server is running', time: new Date().toISOString(), env: 'cloudflare' }));

app.post('/login', async (c) => {
  const { email, password } = await c.req.json();
  const supabase = getSupabase(c);
  
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return c.json({ error: error.message }, 400);

  const user = data.user;
  const role = ['lancarkoreaa@gmail.com', 'jaluganteng404@gmail.com', 'rfingger07@gmail.com'].includes(user.email || '') ? 'admin' : 'user';

  const payload = {
    id: user.id,
    email: user.email,
    role,
    exp: Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60 // 7 days
  };

  const token = await sign(payload, getJWTSecret(c), 'HS256');

  setCookie(c, 'token', token, {
    httpOnly: true,
    secure: true,
    sameSite: 'None',
    maxAge: 7 * 24 * 60 * 60
  });

  return c.json({ id: user.id, email: user.email, role, token });
});

app.post('/register', async (c) => {
  const { email, password, invitationCode } = await c.req.json();
  const supabaseAdmin = getSupabaseAdmin(c);
  const supabase = getSupabase(c);
  const dbClient = supabaseAdmin || supabase;

  const isAdminEmail = ['lancarkoreaa@gmail.com', 'jaluganteng404@gmail.com', 'rfingger07@gmail.com'].includes(email);

  let codeData = null;
  if (!isAdminEmail && invitationCode !== 'LANCARKOREA2024') {
    if (!invitationCode) return c.json({ error: 'Kode undangan wajib diisi.' }, 400);

    const { data, error: codeError } = await dbClient
      .from('invitation_codes')
      .select('*')
      .eq('code', invitationCode)
      .eq('is_used', false)
      .single();

    if (codeError || !data) return c.json({ error: 'Kode undangan tidak valid atau sudah digunakan.' }, 400);
    codeData = data;
  }

  let authData, authError;
  if (supabaseAdmin) {
    const { data, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { role: isAdminEmail ? 'admin' : 'user' }
    });
    authData = data;
    authError = error;
  } else {
    const res = await supabase.auth.signUp({ email, password });
    authData = res.data;
    authError = res.error;
  }

  if (authError) return c.json({ error: authError.message }, 400);

  if (authData.user && codeData) {
    await dbClient
      .from('invitation_codes')
      .update({ is_used: true, used_by: authData.user.id, used_at: Date.now() })
      .eq('id', codeData.id);
  }

  return c.json({ message: 'Registrasi berhasil! Akun Anda sudah aktif dan bisa langsung digunakan untuk login.' });
});

app.get('/state', authMiddleware, async (c) => {
  const user = c.get('user');
  const supabaseAdmin = getSupabaseAdmin(c);
  const supabase = getSupabase(c);
  const dbClient = supabaseAdmin || supabase;

  try {
    const [vocabsRes, grammarsRes, historyRes] = await Promise.all([
      dbClient.from('vocabs').select('*').order('createdAt', { ascending: false }),
      dbClient.from('grammars').select('*').order('createdAt', { ascending: false }),
      dbClient.from('history').select('*').eq('userId', user.id).order('timestamp', { ascending: false })
    ]);

    if (vocabsRes.error) throw vocabsRes.error;
    if (grammarsRes.error) throw grammarsRes.error;
    if (historyRes.error) throw historyRes.error;

    const progress: Record<number, number> = {};
    const history = historyRes.data || [];
    history.forEach((h: any) => {
      h.chapterIds.forEach((chapId: number) => {
        if (progress[chapId] === undefined) {
          progress[chapId] = Math.round((h.score / h.total) * 100);
        }
      });
    });

    return c.json({ vocabs: vocabsRes.data || [], grammars: grammarsRes.data || [], history, progress });
  } catch (err: any) {
    return c.json({ error: err.message }, 500);
  }
});

// Vocabs CRUD
app.post('/vocabs', authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { data, error } = await dbClient.from('vocabs').insert([{ ...body, createdAt: Date.now() }]).select();
  if (error) return c.json({ error: error.message }, 400);
  return c.json(data[0]);
});

app.put('/vocabs/:id', authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param('id');
  const body = await c.req.json();
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { error } = await dbClient.from('vocabs').update(body).eq('id', id);
  if (error) return c.json({ error: error.message }, 400);
  return c.json({ success: true });
});

app.delete('/vocabs', authMiddleware, adminMiddleware, async (c) => {
  const filter = c.req.query('filter');
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  let query = dbClient.from('vocabs').delete();

  if (filter === 'additional') {
    query = query.is('chapterId', null);
  } else if (filter && filter !== 'all') {
    query = query.eq('chapterId', parseInt(filter));
  } else if (filter === 'all') {
    // delete all
  } else {
    return c.json({ error: 'Filter tidak valid.' }, 400);
  }

  const { error } = await query;
  if (error) return c.json({ error: error.message }, 400);
  return c.json({ success: true });
});

app.delete('/vocabs/:id', authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param('id');
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { error } = await dbClient.from('vocabs').delete().eq('id', id);
  if (error) return c.json({ error: error.message }, 400);
  return c.json({ success: true });
});

app.post('/vocabs/bulk', authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const vocabs = body.map((v: any) => ({ ...v, createdAt: Date.now() }));
  const { error } = await dbClient.from('vocabs').insert(vocabs);
  if (error) return c.json({ error: error.message }, 400);
  return c.json({ success: true });
});

// Grammars CRUD
app.post('/grammars', authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { data, error } = await dbClient.from('grammars').insert([{ ...body, createdAt: Date.now() }]).select();
  if (error) return c.json({ error: error.message }, 400);
  return c.json(data[0]);
});

app.put('/grammars/:id', authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param('id');
  const body = await c.req.json();
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { error } = await dbClient.from('grammars').update(body).eq('id', id);
  if (error) return c.json({ error: error.message }, 400);
  return c.json({ success: true });
});

app.delete('/grammars', authMiddleware, adminMiddleware, async (c) => {
  const filter = c.req.query('filter');
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  let query = dbClient.from('grammars').delete();

  if (filter === 'Umum') {
    query = query.eq('level', 'Umum');
  } else if (filter && filter.toString().startsWith('Bab')) {
    query = query.eq('level', filter.toString());
  } else if (filter === 'all') {
    // delete all
  } else {
    return c.json({ error: 'Filter tidak valid.' }, 400);
  }

  const { error } = await query;
  if (error) return c.json({ error: error.message }, 400);
  return c.json({ success: true });
});

app.delete('/grammars/:id', authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param('id');
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { error } = await dbClient.from('grammars').delete().eq('id', id);
  if (error) return c.json({ error: error.message }, 400);
  return c.json({ success: true });
});

// History
app.post('/history', authMiddleware, async (c) => {
  const user = c.get('user');
  const body = await c.req.json();
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { data, error } = await dbClient.from('history').insert([{ ...body, userId: user.id, timestamp: Date.now() }]).select();
  if (error) return c.json({ error: error.message }, 400);
  return c.json(data[0]);
});

// Admin: Invitation Codes
app.get('/admin/invitation-codes', authMiddleware, adminMiddleware, async (c) => {
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { data, error } = await dbClient.from('invitation_codes').select('*').order('created_at', { ascending: false });
  if (error) return c.json({ error: error.message }, 400);
  return c.json(data);
});

app.post('/admin/invitation-codes', authMiddleware, adminMiddleware, async (c) => {
  const { code } = await c.req.json();
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { data, error } = await dbClient.from('invitation_codes').insert([{ code, is_used: false }]).select();
  if (error) return c.json({ error: error.message }, 400);
  return c.json(data[0]);
});

app.post('/admin/invitation-codes/bulk', authMiddleware, adminMiddleware, async (c) => {
  const { count } = await c.req.json();
  if (!count || count <= 0) return c.json({ error: 'Jumlah harus diisi.' }, 400);

  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const codes = Array.from({ length: count }).map(() => {
    let code = 'LK-';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return { code, is_used: false };
  });

  const { data, error } = await dbClient.from('invitation_codes').insert(codes).select();
  if (error) return c.json({ error: error.message }, 400);
  return c.json(data);
});

app.delete('/admin/invitation-codes/:id', authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param('id');
  const dbClient = getSupabaseAdmin(c) || getSupabase(c);
  const { error } = await dbClient.from('invitation_codes').delete().eq('id', id);
  if (error) return c.json({ error: error.message }, 400);
  return c.json({ success: true });
});

// Admin: Change Password
app.post('/admin/change-password', authMiddleware, adminMiddleware, async (c) => {
  const { email, newPassword } = await c.req.json();
  const supabaseAdmin = getSupabaseAdmin(c);
  if (!supabaseAdmin) return c.json({ error: 'Admin client not configured' }, 500);

  try {
    const { data } = await supabaseAdmin.auth.admin.listUsers();
    const targetUser = (data.users as any[]).find(u => u.email?.toLowerCase() === email.toLowerCase());
    if (!targetUser) return c.json({ error: 'User not found' }, 404);

    const { error } = await supabaseAdmin.auth.admin.updateUserById(targetUser.id, { password: newPassword });
    if (error) throw error;

    return c.json({ message: `Password untuk ${email} berhasil diperbarui.` });
  } catch (err: any) {
    return c.json({ error: err.message }, 500);
  }
});

export const onRequest = handle(app);
