
export interface Vocab {
  id: string;
  word: string;
  meaning: string;
  chapterId?: number; // 1-60, or undefined for "Additional"
  imageUrl?: string;
  isUnit?: boolean;
  unitType?: 'native' | 'sino';
  createdAt: number;
}

export interface Grammar {
  id: string;
  title: string; // tatabahasa
  meaning: string; // arti
  description: string; // penjelasan singkat
  exampleSentence: string; // contoh kalimat
  exampleExplanation: string; // penjelasan contoh kalimat
  level: string; // tingkatan (e.g., 'Umum', 'Bab 22')
  tags: string[]; // tag
  notes: string; // tips/catatan
  createdAt: number;
}

export interface Chapter {
  id: number;
  title: string;
}

export interface PracticeSession {
  type: 'meaning' | 'image' | 'reverse' | 'random' | 'grammar' | 'unit';
  chapterIds: number[]; // empty means all or specific additional
  includeAdditional: boolean;
  unitFilter?: 'all' | 'native' | 'sino';
}

export interface PracticeHistory {
  id: string;
  userId: string;
  type: string;
  chapterIds: number[];
  includeAdditional: boolean;
  score: number;
  total: number;
  timestamp: number;
}

export interface User {
  id: string;
  email: string;
  role: 'admin' | 'user';
}

export interface AppState {
  vocabs: Vocab[];
  grammars: Grammar[];
  history: PracticeHistory[];
  progress: Record<number, number>; // chapterId -> percentage
}
