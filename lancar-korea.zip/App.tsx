
import { useState, useEffect, useCallback, FC } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Setoran from './components/Setoran';
import ChapterList from './components/ChapterList';
import ChapterDetail from './components/ChapterDetail';
import Practice from './components/Practice';
import Grammar from './components/Grammar';
import Units from './components/Units';
import Login from './components/Login';
import Admin from './components/Admin';
import { db } from './services/db';
import { AppState, User } from './types';

const App: FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedChapter, setSelectedChapter] = useState<number | null>(null);
  const [appState, setAppState] = useState<AppState>({
    vocabs: [],
    grammars: [],
    history: [],
    progress: {},
  });
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('lancar_korea_user');
    return saved ? JSON.parse(saved) : null;
  });

  const refreshState = useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      // 1. Try to get from cache first for instant load
      const cached = await db.getCache();
      if (cached) {
        setAppState(cached);
        // We don't set loading to false here if we want to fetch fresh data in background
        // but the original code did it. Let's keep it consistent but safer.
      }

      // 2. Fetch fresh data from Supabase in background
      const state = await db.get();
      setAppState(state);
    } catch (error) {
      console.error("Failed to fetch state:", error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      refreshState();
    } else {
      setLoading(false);
    }
  }, [refreshState, user]);

  const handleTabChange = (id: string) => {
    setActiveTab(id);
    setSelectedChapter(null); // Reset chapter view when changing tabs
  };

  const handleSelectChapter = (id: number) => {
    setSelectedChapter(id);
  };

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('lancar_korea_user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('lancar_korea_user');
  };

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-zinc-500 font-bold text-xs uppercase tracking-widest">Memuat Data...</p>
        </div>
      </div>
    );
  }

  return (
    <Layout 
      activeTab={activeTab} 
      onTabChange={handleTabChange} 
      user={user} 
      onLogout={handleLogout}
    >
      <div className="relative w-full h-full">
        {/* Conditional Rendering for Tabs (Lightweight) */}
        {activeTab === 'dashboard' && <Dashboard state={appState} />}
        {activeTab === 'setoran' && <Setoran onRefresh={refreshState} vocabs={appState.vocabs} user={user} />}
        {activeTab === 'bab' && (
          selectedChapter !== null ? (
            <ChapterDetail 
              chapterId={selectedChapter} 
              vocabs={appState.vocabs} 
              onBack={() => setSelectedChapter(null)} 
            />
          ) : (
            <ChapterList vocabs={appState.vocabs} onSelectChapter={handleSelectChapter} />
          )
        )}
        {activeTab === 'grammar' && <Grammar grammars={appState.grammars} onRefresh={refreshState} user={user} />}
        {activeTab === 'units' && <Units vocabs={appState.vocabs} onTabChange={handleTabChange} onRefresh={refreshState} user={user} />}
        {activeTab === 'practice' && <Practice vocabs={appState.vocabs} grammars={appState.grammars} onRefresh={refreshState} user={user} />}
        {activeTab === 'admin' && user?.role === 'admin' && <Admin />}
      </div>
    </Layout>
  );
};

export default App;
