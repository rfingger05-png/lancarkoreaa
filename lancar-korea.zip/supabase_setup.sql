
-- Lancar Korea - Supabase Database Setup
-- This script sets up the necessary tables and policies for the Lancar Korea application.

-- 1. Create Vocabs Table
-- Stores vocabulary words, meanings, and associated metadata.
CREATE TABLE IF NOT EXISTS public.vocabs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    word TEXT NOT NULL,
    meaning TEXT NOT NULL,
    "chapterId" INTEGER, -- 1-60, or NULL for "Additional"
    "imageUrl" TEXT,
    "isUnit" BOOLEAN DEFAULT FALSE,
    "unitType" TEXT, -- 'native' or 'sino'
    "createdAt" BIGINT NOT NULL -- Timestamp in milliseconds
);

-- 2. Create Grammars Table
-- Stores grammar points, explanations, and examples.
CREATE TABLE IF NOT EXISTS public.grammars (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    meaning TEXT NOT NULL,
    description TEXT,
    "exampleSentence" TEXT,
    "exampleExplanation" TEXT,
    level TEXT,
    tags TEXT[] DEFAULT '{}'::text[],
    notes TEXT,
    "createdAt" BIGINT NOT NULL -- Timestamp in milliseconds
);

-- 3. Create Practice History Table
-- Stores user practice results and scores.
CREATE TABLE IF NOT EXISTS public.history (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    "userId" UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    "chapterIds" INTEGER[] DEFAULT '{}'::integer[],
    "includeAdditional" BOOLEAN DEFAULT FALSE,
    score INTEGER NOT NULL,
    total INTEGER NOT NULL,
    timestamp BIGINT NOT NULL -- Timestamp in milliseconds
);

-- 4. Create Invitation Codes Table
-- Stores codes used for user registration.
CREATE TABLE IF NOT EXISTS public.invitation_codes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    is_used BOOLEAN DEFAULT FALSE,
    used_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    used_at BIGINT, -- Timestamp in milliseconds
    created_at BIGINT DEFAULT (EXTRACT(EPOCH FROM NOW()) * 1000) -- Timestamp in milliseconds
);

-- 5. Enable Row Level Security (RLS)
-- This ensures that data access is controlled.
ALTER TABLE public.vocabs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.grammars ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invitation_codes ENABLE ROW LEVEL SECURITY;

-- 6. Create RLS Policies
-- For simplicity and to match the Express server's current implementation (which uses the anon key),
-- we allow all operations for now. In a production environment, you should tighten these.

-- Vocabs Policies
CREATE POLICY "Allow all access to vocabs" ON public.vocabs FOR ALL USING (true);

-- Grammars Policies
CREATE POLICY "Allow all access to grammars" ON public.grammars FOR ALL USING (true);

-- History Policies
CREATE POLICY "Allow all access to history" ON public.history FOR ALL USING (true);

-- Invitation Codes Policies
CREATE POLICY "Allow all access to invitation_codes" ON public.invitation_codes FOR ALL USING (true);

-- 7. Indexes for Performance
CREATE INDEX IF NOT EXISTS idx_vocabs_chapter ON public.vocabs("chapterId");
CREATE INDEX IF NOT EXISTS idx_history_user ON public.history("userId");
CREATE INDEX IF NOT EXISTS idx_invitation_codes_code ON public.invitation_codes(code);
