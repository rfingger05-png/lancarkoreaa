import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import { rateLimit } from 'express-rate-limit';

dotenv.config();

// Helper to get __dirname in ESM
const __dirname = process.cwd();
export const app = express();
const PORT = 3000;

// Trust proxy for express-rate-limit
app.set('trust proxy', 1);

// Supabase Setup
const getSupabase = () => {
  const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '';
  const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || '';
  
  if (!supabaseUrl || !supabaseKey) {
    throw new Error('Konfigurasi Supabase (URL/Key) tidak ditemukan di environment variables.');
  }
  
  return createClient(supabaseUrl, supabaseKey);
};

const getSupabaseAdmin = () => {
  const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '';
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
  
  if (!supabaseUrl || !supabaseServiceKey) {
    return null;
  }
  
  return createClient(supabaseUrl, supabaseServiceKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  });
};

const JWT_SECRET = process.env.JWT_SECRET || 'lancar-korea-secret-key-123';

// --- Middlewares ---
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

// Rate limiting (Disabled for debugging)
const limiter = (req: any, res: any, next: any) => next();
/*
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: { error: 'Terlalu banyak permintaan dari IP ini, silakan coba lagi nanti.' }
});
*/

// Debug middleware
app.use((req, res, next) => {
  console.log(`[DEBUG] ${req.method} ${req.path} (Original: ${req.originalUrl})`);
  next();
});

// Auth Middleware
const authenticateToken = (req: any, res: any, next: any) => {
  const token = req.cookies?.token || req.headers['authorization']?.split(' ')[1];
  
  if (!token) return res.status(401).json({ error: 'Akses ditolak. Silakan login.' });

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(401).json({ error: 'Sesi habis. Silakan login kembali.' });
    req.user = user;
    next();
  });
};

const isAdmin = (req: any, res: any, next: any) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Akses Ditolak: Hanya Admin yang bisa melakukan tindakan ini.' });
  }
  next();
};

// --- API Routes ---
const apiRouter = express.Router();
apiRouter.use(limiter);

// Health Check
apiRouter.get('/health', (req, res) => res.json({ status: 'ok', env: process.env.NETLIFY === 'true' ? 'netlify' : 'local' }));
apiRouter.get('/debug', (req, res) => res.json({ 
  ok: true, 
  message: 'Server is running', 
  time: new Date().toISOString(),
  env: process.env.NETLIFY === 'true' ? 'netlify' : 'local'
}));

// Auth
apiRouter.post('/register', async (req, res) => {
  const { email, password, invitationCode } = req.body;
// ... (rest of register logic)

  // 1. Check if unique invitation code exists and is not used
  // Invitation code is MANDATORY to prevent spam registrations
  let codeData = null;
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  
  // Admin emails can bypass invitation code
  const isAdminEmail = email === 'lancarkoreaa@gmail.com' || email === 'jaluganteng404@gmail.com' || email === 'rfingger07@gmail.com';
  
  if (!isAdminEmail && invitationCode !== 'LANCARKOREA2024') {
    if (!invitationCode) {
      return res.status(400).json({ error: 'Kode undangan wajib diisi.' });
    }

    const { data, error: codeError } = await dbClient
      .from('invitation_codes')
      .select('*')
      .eq('code', invitationCode)
      .eq('is_used', false)
      .single();

    if (codeError || !data) {
      return res.status(400).json({ error: 'Kode undangan tidak valid atau sudah digunakan.' });
    }
    codeData = data;
  }
  
  // 2. Proceed with user creation
  let authData, authError;
  try {
    if (supabaseAdmin) {
      // Use admin client to create user with email_confirm: true to bypass email verification
      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { role: (email === 'lancarkoreaa@gmail.com' || email === 'jaluganteng404@gmail.com') ? 'admin' : 'user' }
      });
      authData = data;
      authError = error;
    } else {
      // Fallback to standard signup if admin client is not configured
      const res = await supabase.auth.signUp({
        email,
        password,
      });
      authData = res.data;
      authError = res.error;
    }
  } catch (err: any) {
    console.error('Registration Error:', err);
    return res.status(500).json({ error: 'Gagal terhubung ke database. Periksa konfigurasi Supabase Anda.' });
  }

  if (authError) return res.status(400).json({ error: authError.message });

  // 3. Mark the invitation code as used
  if (authData.user && codeData) {
    await dbClient
      .from('invitation_codes')
      .update({ 
        is_used: true, 
        used_by: authData.user.id,
        used_at: Date.now()
      })
      .eq('id', codeData.id);
  }

  res.json({ 
    message: 'Registrasi berhasil! Akun Anda sudah aktif dan bisa langsung digunakan untuk login.',
    requiresConfirmation: false 
  });
});

apiRouter.post('/login', async (req, res) => {
  const { email, password } = req.body;

  let authData, authError;
  try {
    const supabase = getSupabase();
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    authData = data;
    authError = error;
  } catch (err: any) {
    console.error('Supabase Auth Error:', err);
    return res.status(500).json({ error: 'Gagal terhubung ke database. Periksa konfigurasi Supabase Anda.' });
  }

  if (authError) return res.status(400).json({ error: authError.message });

  const user = authData.user;
  const role = (user.email === 'lancarkoreaa@gmail.com' || user.email === 'jaluganteng404@gmail.com' || user.email === 'rfingger07@gmail.com') ? 'admin' : 'user';

  const token = jwt.sign({ id: user.id, email: user.email, role }, JWT_SECRET, { expiresIn: '7d' });

  res.cookie('token', token, { 
    httpOnly: true, 
    secure: true, 
    sameSite: 'none',
    maxAge: 7 * 24 * 60 * 60 * 1000 
  });

  res.json({ id: user.id, email: user.email, role, token });
});

// App State (Vocabs, Grammars, History)
apiRouter.get('/state', authenticateToken, async (req: any, res) => {
  try {
    const supabaseAdmin = getSupabaseAdmin();
    const supabase = getSupabase();
    const dbClient = supabaseAdmin || supabase;
    const [vocabsRes, grammarsRes, historyRes] = await Promise.all([
      dbClient.from('vocabs').select('*').order('createdAt', { ascending: false }),
      dbClient.from('grammars').select('*').order('createdAt', { ascending: false }),
      dbClient.from('history').select('*').eq('userId', req.user.id).order('timestamp', { ascending: false })
    ]);

    if (vocabsRes.error) throw vocabsRes.error;
    if (grammarsRes.error) throw grammarsRes.error;
    if (historyRes.error) throw historyRes.error;

    // Calculate progress (Latest attempt for each chapter)
    const progress: Record<number, number> = {};
    const history = historyRes.data || [];
    
    // Since history is ordered by timestamp DESC, the first time we see a chapId, it's the latest
    history.forEach(h => {
      h.chapterIds.forEach((chapId: number) => {
        if (progress[chapId] === undefined) {
          const percentage = (h.score / h.total) * 100;
          progress[chapId] = Math.round(percentage);
        }
      });
    });

    res.json({
      vocabs: vocabsRes.data || [],
      grammars: grammarsRes.data || [],
      history: history,
      progress
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Vocabs CRUD
apiRouter.post('/vocabs', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { data, error } = await dbClient.from('vocabs').insert([{ ...req.body, createdAt: Date.now() }]).select();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data[0]);
});

apiRouter.put('/vocabs/:id', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { error } = await dbClient.from('vocabs').update(req.body).eq('id', req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true });
});

apiRouter.delete('/vocabs', authenticateToken, isAdmin, async (req, res) => {
  const { filter } = req.query;
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;

  let query = dbClient.from('vocabs').delete();

  if (filter === 'additional') {
    query = query.is('chapterId', null);
  } else if (filter && filter !== 'all') {
    query = query.eq('chapterId', parseInt(filter as string));
  } else if (filter === 'all') {
    // No filter, delete everything
  } else {
    return res.status(400).json({ error: 'Filter tidak valid.' });
  }

  const { error } = await query;
  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true });
});

apiRouter.delete('/vocabs/:id', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { error } = await dbClient.from('vocabs').delete().eq('id', req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true });
});

apiRouter.post('/vocabs/bulk', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const vocabs = req.body.map((v: any) => ({ ...v, createdAt: Date.now() }));
  const { error } = await dbClient.from('vocabs').insert(vocabs);
  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true });
});

// Grammars CRUD
apiRouter.post('/grammars', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { data, error } = await dbClient.from('grammars').insert([{ ...req.body, createdAt: Date.now() }]).select();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data[0]);
});

apiRouter.put('/grammars/:id', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { error } = await dbClient.from('grammars').update(req.body).eq('id', req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true });
});

apiRouter.delete('/grammars', authenticateToken, isAdmin, async (req, res) => {
  const { filter } = req.query;
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;

  let query = dbClient.from('grammars').delete();

  if (filter === 'Umum') {
    query = query.eq('level', 'Umum');
  } else if (filter && filter.toString().startsWith('Bab')) {
    query = query.eq('level', filter.toString());
  } else if (filter === 'all') {
    // No filter, delete everything
  } else {
    return res.status(400).json({ error: 'Filter tidak valid.' });
  }

  const { error } = await query;
  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true });
});

apiRouter.delete('/grammars/:id', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { error } = await dbClient.from('grammars').delete().eq('id', req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true });
});

// History
apiRouter.post('/history', authenticateToken, async (req: any, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { data, error } = await dbClient.from('history').insert([{ 
    ...req.body, 
    userId: req.user.id, 
    timestamp: Date.now() 
  }]).select();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data[0]);
});

// Invitation Codes Management (Admin Only)
apiRouter.get('/admin/invitation-codes', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { data, error } = await dbClient
    .from('invitation_codes')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

apiRouter.post('/admin/invitation-codes', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { code } = req.body;
  if (!code) return res.status(400).json({ error: 'Kode harus diisi.' });

  const { data, error } = await dbClient
    .from('invitation_codes')
    .insert([{ code, is_used: false }])
    .select();
  
  if (error) return res.status(400).json({ error: error.message });
  res.json(data[0]);
});

apiRouter.post('/admin/invitation-codes/bulk', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { count } = req.body;
  if (!count || count <= 0) return res.status(400).json({ error: 'Jumlah harus diisi.' });

  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const codes = Array.from({ length: count }).map(() => {
    let code = 'LK-';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return { code, is_used: false };
  });

  const { data, error } = await dbClient
    .from('invitation_codes')
    .insert(codes)
    .select();
  
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

apiRouter.delete('/admin/invitation-codes/:id', authenticateToken, isAdmin, async (req, res) => {
  const supabaseAdmin = getSupabaseAdmin();
  const supabase = getSupabase();
  const dbClient = supabaseAdmin || supabase;
  const { error } = await dbClient
    .from('invitation_codes')
    .delete()
    .eq('id', req.params.id);
  
  if (error) return res.status(400).json({ error: error.message });
  res.json({ success: true });
});

// Admin: Change User Password
apiRouter.post('/admin/change-password', authenticateToken, isAdmin, async (req, res) => {
  const { email, newPassword } = req.body;
  const supabaseAdmin = getSupabaseAdmin();
  console.log(`[Admin] Request ganti password untuk: ${email}`);

  if (!email || !newPassword) {
    return res.status(400).json({ error: 'Email dan password baru harus diisi.' });
  }

  if (!supabaseAdmin) {
    console.error('[Admin] SUPABASE_SERVICE_ROLE_KEY tidak ditemukan!');
    return res.status(500).json({ error: 'Konfigurasi server tidak lengkap (Service Role Key missing).' });
  }

  try {
    // 1. Cari user berdasarkan email (case-insensitive)
    const { data, error: listError } = await supabaseAdmin.auth.admin.listUsers();
    
    if (listError) {
      console.error('[Admin] Gagal list users:', listError);
      if (listError.message.includes('api key')) {
        return res.status(500).json({ 
          error: 'SUPABASE_SERVICE_ROLE_KEY Anda tidak valid. Pastikan Anda menyalin "service_role" key dari menu API di Supabase (yang diawali dengan "eyJ").' 
        });
      }
      throw listError;
    }

    const targetUser = (data.users as any[]).find(u => 
      u.email?.toLowerCase() === email.toLowerCase()
    );

    if (!targetUser) {
      console.warn(`[Admin] User tidak ditemukan: ${email}`);
      return res.status(404).json({ error: 'Pengguna dengan email tersebut tidak ditemukan di database Auth.' });
    }

    console.log(`[Admin] User ditemukan (ID: ${targetUser.id}), mengupdate password...`);

    // 2. Update password
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
      targetUser.id,
      { password: newPassword }
    );

    if (updateError) {
      console.error('[Admin] Gagal update password:', updateError);
      throw updateError;
    }

    console.log(`[Admin] Berhasil update password untuk: ${email}`);
    res.json({ message: `Password untuk ${email} berhasil diperbarui.` });
  } catch (error: any) {
    console.error('Admin Password Change Error:', error);
    res.status(500).json({ error: error.message || 'Gagal memperbarui password.' });
  }
});

// Mount the router
// Robust path handling for both local and Netlify
app.use((req, res, next) => {
  // Strip prefixes if they exist so apiRouter can match at root
  if (req.url.startsWith('/.netlify/functions/api')) {
    req.url = req.url.replace('/.netlify/functions/api', '');
  } else if (req.url.startsWith('/api')) {
    req.url = req.url.replace('/api', '');
  }
  next();
});

// Mount at root, /api, and the function path just to be absolutely sure
app.use(['/api', '/.netlify/functions/api', '/'], apiRouter);

// Global 404 Fallback for API
app.use((req, res, next) => {
  const isApi = req.path.startsWith('/api') || 
                req.path.startsWith('/.netlify') || 
                req.headers.accept?.includes('application/json');
  
  if (isApi) {
    return res.status(404).json({ 
      error: 'Not Found',
      message: `Rute API tidak ditemukan: ${req.method} ${req.path}`,
      debug: { path: req.path, env: process.env.NETLIFY === 'true' ? 'netlify' : 'local' }
    });
  }
  next();
});

// Global Error Handler
app.use((err: any, req: any, res: any, next: any) => {
  console.error('[SERVER ERROR]', err);
  if (req.path.startsWith('/api') || req.path.startsWith('/.netlify') || req.headers.accept?.includes('application/json')) {
    return res.status(err.status || 500).json({
      error: err.message || 'Internal Server Error',
      env: process.env.NETLIFY === 'true' ? 'netlify' : 'local'
    });
  }
  next(err);
});

// --- Vite & Static Files ---

async function startServer() {
  // On Netlify, we don't need Vite or static file serving via Express
  // because Netlify handles it.
  if (process.env.NETLIFY === 'true') {
    return;
  }

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

// Start server if not in Netlify
if (process.env.NETLIFY !== 'true') {
  startServer().catch(console.error);
}

export default app;
